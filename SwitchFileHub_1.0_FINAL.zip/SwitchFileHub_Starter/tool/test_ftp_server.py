#!/usr/bin/env python3
"""Servidor FTP de TESTE (pyftpdlib) para validar o Switch File Hub sem console.

    pip install pyftpdlib
    python tool/test_ftp_server.py --port 2121 --root ./ftp_root

Acesso anônimo com permissão total, modo passivo. Use apenas em rede local.
Isto simula o FTPD, mas NÃO substitui o teste com um Nintendo Switch real.
"""
import argparse, os
from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer

ap = argparse.ArgumentParser()
ap.add_argument("--host", default="127.0.0.1")
ap.add_argument("--port", type=int, default=2121)
ap.add_argument("--root", default="./ftp_root")
a = ap.parse_args()
os.makedirs(a.root, exist_ok=True)
auth = DummyAuthorizer()
auth.add_anonymous(os.path.abspath(a.root), perm="elradfmwMT")
FTPHandler.authorizer = auth
FTPHandler.passive_ports = range(60000, 60100)
FTPHandler.permit_foreign_addresses = True
print(f"FTP de teste em {a.host}:{a.port}, raiz {os.path.abspath(a.root)}")
FTPServer((a.host, a.port), FTPHandler).serve_forever()
