import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:switch_file_hub/main.dart';
import 'package:switch_file_hub/services/persistence.dart';
import 'package:switch_file_hub/state/app_controller.dart';

void main() {
  testWidgets('abre na tela Início e navega para Conectar Switch',
      (tester) async {
    SharedPreferences.setMockInitialValues({});
    tester.view.physicalSize = const Size(1400, 900);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.reset);

    final controller = AppController(await Persistence.open());
    await tester.pumpWidget(SwitchFileHubApp(controller: controller));
    await tester.pumpAndSettle();

    expect(find.text('Switch File Hub'), findsWidgets);
    expect(find.text('Switch não conectado'), findsOneWidget);

    await tester.tap(find.text('Conectar Switch'));
    await tester.pumpAndSettle();
    expect(find.text('Testar conexão'), findsOneWidget);
    expect(find.byType(TextField), findsNWidgets(4));
  });
}
