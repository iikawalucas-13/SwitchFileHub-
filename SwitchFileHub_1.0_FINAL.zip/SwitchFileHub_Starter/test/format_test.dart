import 'package:flutter_test/flutter_test.dart';
import 'package:switch_file_hub/core/format.dart';
import 'package:switch_file_hub/core/models.dart';
import 'package:switch_file_hub/services/discovery.dart';
import 'package:switch_file_hub/services/ftp_client.dart';

void main() {
  group('validateName', () {
    test('aceita nomes normais', () {
      expect(validateName('jogo.nsp'), isNull);
      expect(validateName('Minha Pasta'), isNull);
    });
    test('rejeita vazios, ponto, traversal e separadores', () {
      for (final bad in ['', '  ', '.', '..', 'a/b', r'a\b', 'x:y', 'a*b', 'a?']) {
        expect(validateName(bad), isNotNull, reason: bad);
      }
    });
    test('rejeita ponto/espaço final e nomes longos', () {
      expect(validateName('abc.'), isNotNull);
      expect(validateName('abc '.padRight(4, ' ')), isNull); // trim
      expect(validateName('a' * 256), isNotNull);
    });
  });

  group('caminhos remotos', () {
    test('normalizeRemotePath', () {
      expect(normalizeRemotePath('/switch//homebrew/'), '/switch/homebrew');
      expect(normalizeRemotePath('/'), '/');
      expect(normalizeRemotePath('/a/../b'), isNull);
      expect(normalizeRemotePath('/a\n/b'), isNull);
    });
    test('parentRemote e joinRemote', () {
      expect(parentRemote('/a/b'), '/a');
      expect(parentRemote('/a'), '/');
      expect(parentRemote('/'), '/');
      expect(joinRemote('/', 'x'), '/x');
      expect(joinRemote('/a', 'x'), '/a/x');
    });
  });

  test('sanitizeLocalName', () {
    expect(sanitizeLocalName('a:b?c'), 'a_b_c');
    expect(sanitizeLocalName('..'), '_');
    expect(sanitizeLocalName('ok.txt'), 'ok.txt');
  });

  test('formatSize / formatEta / formatSpeed', () {
    expect(formatSize(null), 'Tamanho desconhecido');
    expect(formatSize(512), '512 B');
    expect(formatSize(1536), '1.5 KB');
    expect(formatSize(5 * 1024 * 1024), '5.0 MB');
    expect(formatSize(3 * 1024 * 1024 * 1024), '3.00 GB');
    expect(formatEta(null), '—');
    expect(formatEta(const Duration(seconds: 75)), '1min 15s');
    expect(formatEta(const Duration(hours: 2, minutes: 5)), '2h 5min');
    expect(formatSpeed(2048), '2.0 KB/s');
  });

  group('parsers de listagem FTP', () {
    test('MLSD', () {
      const txt = 'type=cdir;modify=20240101000000; .\r\n'
          'type=pdir;modify=20240101000000; ..\r\n'
          'type=dir;modify=20240101000000; switch\r\n'
          'type=file;size=1234;modify=20240101000000; jogo com espaço.nsp\r\n';
      final r = FtpClient.parseMlsd(txt);
      expect(r.map((e) => e.name), ['switch', 'jogo com espaço.nsp']);
      expect(r[0].isDir, isTrue);
      expect(r[1].size, 1234);
    });
    test('LIST estilo Unix', () {
      const txt = 'total 8\r\n'
          'drwxr-xr-x   2 user group        0 Jan  1 12:00 atmosphere\r\n'
          '-rw-r--r--   1 user group  5242880 Mar 12  2023 big file.bin\r\n'
          'lrwxrwxrwx   1 user group       4 Jan  1 12:00 ln -> alvo\r\n';
      final r = FtpClient.parseList(txt);
      expect(r.length, 3);
      expect(r[0].isDir, isTrue);
      expect(r[1].name, 'big file.bin');
      expect(r[1].size, 5242880);
      expect(r[2].isLink, isTrue);
      expect(r[2].name, 'ln');
    });
    test('LIST estilo DOS', () {
      const txt = '01-02-24  10:30AM       <DIR>          pasta\r\n'
          '01-02-24  10:30AM              2048 a.txt\r\n';
      final r = FtpClient.parseList(txt);
      expect(r[0].isDir, isTrue);
      expect(r[1].size, 2048);
    });
  });

  test('subnetHosts', () {
    final h = subnetHosts('192.168.1.25');
    expect(h.length, 253);
    expect(h.contains('192.168.1.25'), isFalse);
    expect(h.first, '192.168.1.1');
    expect(subnetHosts('x'), isEmpty);
  });

  test('redact remove a senha', () {
    expect(redact('login failed for hunter2', 'hunter2'), 'login failed for ***');
    expect(redact('abc', ''), 'abc');
  });

  test('HistoryEntry ida e volta em JSON', () {
    final h = HistoryEntry(
        time: DateTime.fromMillisecondsSinceEpoch(1700000000000),
        kind: HistoryKind.upload,
        name: 'a.bin',
        status: 'ok',
        detail: 'x',
        bytes: 42);
    final r = HistoryEntry.fromJson(h.toJson())!;
    expect(r.kind, HistoryKind.upload);
    expect(r.bytes, 42);
    expect(r.time, h.time);
    expect(HistoryEntry.fromJson('lixo'), isNull);
  });

  test('TransferJob.fraction', () {
    final j = TransferJob(
        id: 1,
        direction: TransferDirection.upload,
        name: 'a',
        localPath: 'a',
        remoteDir: '/',
        remoteName: 'a',
        totalBytes: 200)
      ..transferred = 50;
    expect(j.fraction, 0.25);
    j.totalBytes = null;
    expect(j.fraction, isNull);
  });
}
