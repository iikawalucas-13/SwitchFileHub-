// Teste de integração contra um servidor FTP REAL (não é mock).
// Só roda se as variáveis de ambiente estiverem definidas:
//   SFH_FTP_HOST, SFH_FTP_PORT  (ex.: 127.0.0.1 / 2121)
// Servidor de teste: python tool/test_ftp_server.py --port 2121 --root <dir>
// Isso NÃO substitui o teste com o Nintendo Switch físico.
import 'dart:async';
import 'dart:io';
import 'dart:math';

import 'package:flutter_test/flutter_test.dart';
import 'package:switch_file_hub/core/models.dart';
import 'package:switch_file_hub/services/ftp_session.dart';
import 'package:switch_file_hub/services/transfer_manager.dart';

Future<void> waitFor(bool Function() cond,
    {Duration timeout = const Duration(seconds: 60)}) async {
  final sw = Stopwatch()..start();
  while (!cond()) {
    if (sw.elapsed > timeout) throw TimeoutException('waitFor');
    await Future<void>.delayed(const Duration(milliseconds: 5));
  }
}

void main() {
  final host = Platform.environment['SFH_FTP_HOST'];
  final port = int.tryParse(Platform.environment['SFH_FTP_PORT'] ?? '');
  final skip = (host == null || port == null)
      ? 'Defina SFH_FTP_HOST e SFH_FTP_PORT para rodar'
      : false;

  ConnectionSettings settings() =>
      ConnectionSettings(host: host!, port: port!, timeoutSeconds: 10);

  late Directory tmp;
  setUp(() => tmp = Directory.systemTemp.createTempSync('sfh_it'));
  tearDown(() => tmp.deleteSync(recursive: true));

  test('conectar, listar, criar pasta, renomear e excluir', () async {
    final s = FtpSession(settings());
    await s.connect();
    final name = 'it_${DateTime.now().millisecondsSinceEpoch}';
    await s.makeDirectory(name);
    expect((await s.list()).any((e) => e.name == name && e.isDir), isTrue);
    await s.rename(name, '${name}_r');
    final after = await s.list();
    expect(after.any((e) => e.name == '${name}_r'), isTrue);
    expect(after.any((e) => e.name == name), isFalse);
    await s.deleteDirectory('${name}_r');
    expect((await s.list()).any((e) => e.name == '${name}_r'), isFalse);
    await s.disconnect();
  }, skip: skip);

  test('conexão recusada gera erro amigável', () async {
    final s = FtpSession(ConnectionSettings(host: '127.0.0.1', port: 1));
    expect(s.connect(), throwsA(isA<Exception>()));
  }, skip: skip);

  test('upload e download de arquivo grande (20 MB) com SHA idêntico',
      () async {
    final src = File('${tmp.path}/big.bin');
    final raf = src.openSync(mode: FileMode.write);
    final rnd = Random(7);
    for (var i = 0; i < 20; i++) {
      raf.writeFromSync(List<int>.generate(1024 * 1024, (_) => rnd.nextInt(256)));
    }
    raf.closeSync();

    final dir = '/it_big_${DateTime.now().millisecondsSinceEpoch}';
    final tm = TransferManager(settings: settings, onFinished: (_) {});
    final up = TransferJob(
        id: tm.nextId,
        direction: TransferDirection.upload,
        name: 'big.bin',
        localPath: src.path,
        remoteDir: dir,
        remoteName: 'big.bin');
    tm.enqueue([up]);
    await waitFor(() => up.isFinished);
    expect(up.state, TransferState.done, reason: up.error);

    final dst = File('${tmp.path}/out/big.bin');
    final down = TransferJob(
        id: tm.nextId,
        direction: TransferDirection.download,
        name: 'big.bin',
        localPath: dst.path,
        remoteDir: dir,
        remoteName: 'big.bin',
        totalBytes: 20 * 1024 * 1024);
    tm.enqueue([down]);
    await waitFor(() => down.isFinished);
    expect(down.state, TransferState.done, reason: down.error);
    expect(dst.lengthSync(), src.lengthSync());
    expect(await dst.readAsBytes(), await src.readAsBytes());
    expect(File('${dst.path}.sfhpart').existsSync(), isFalse);

    // não substitui silenciosamente: reenvio sem overwrite é "pulado"
    final again = TransferJob(
        id: tm.nextId,
        direction: TransferDirection.upload,
        name: 'big.bin',
        localPath: src.path,
        remoteDir: dir,
        remoteName: 'big.bin');
    tm.enqueue([again]);
    await waitFor(() => again.isFinished);
    expect(again.state, TransferState.skipped);

    final s = FtpSession(settings());
    await s.connect();
    await s.changeDirectory('/');
    await s.deleteDirectory(dir.substring(1));
    await s.disconnect();
    tm.dispose();
  }, skip: skip, timeout: const Timeout(Duration(minutes: 3)));

  test('cancelar transferência em andamento remove o arquivo parcial',
      () async {
    final src = File('${tmp.path}/huge.bin');
    final raf = src.openSync(mode: FileMode.write)..truncateSync(400 * 1024 * 1024);
    raf.closeSync();
    final dir = '/it_cancel_${DateTime.now().millisecondsSinceEpoch}';
    final tm = TransferManager(settings: settings, onFinished: (_) {});
    final job = TransferJob(
        id: tm.nextId,
        direction: TransferDirection.upload,
        name: 'huge.bin',
        localPath: src.path,
        remoteDir: dir,
        remoteName: 'huge.bin');
    tm.enqueue([job]);
    await waitFor(() => job.transferred > 0 || job.isFinished);
    tm.cancel(job);
    await waitFor(() => job.isFinished);
    expect(job.state, TransferState.cancelled);

    final s = FtpSession(settings());
    await s.connect();
    expect(await s.fileExists(dir, 'huge.bin'), isFalse);
    await s.changeDirectory('/');
    await s.deleteDirectory(dir.substring(1));
    await s.disconnect();
    tm.dispose();
  }, skip: skip, timeout: const Timeout(Duration(minutes: 3)));
}
