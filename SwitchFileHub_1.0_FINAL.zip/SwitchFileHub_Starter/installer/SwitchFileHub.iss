; Instalador do Switch File Hub (Inno Setup 6). Compile após "flutter build windows --release"
; e a montagem de dist\SwitchFileHub (ver .github/workflows/build.yml).
[Setup]
AppName=Switch File Hub
AppVersion=1.0.0
AppPublisher=Switch File Hub
DefaultDirName={autopf}\Switch File Hub
DefaultGroupName=Switch File Hub
OutputDir=Output
OutputBaseFilename=SwitchFileHub_Setup
Compression=lzma2
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=lowest
UninstallDisplayIcon={app}\SwitchFileHub.exe

[Languages]
Name: "brazilianportuguese"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Files]
Source: "..\dist\SwitchFileHub\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion

[Icons]
Name: "{group}\Switch File Hub"; Filename: "{app}\SwitchFileHub.exe"
Name: "{autodesktop}\Switch File Hub"; Filename: "{app}\SwitchFileHub.exe"

[Run]
Filename: "{app}\SwitchFileHub.exe"; Description: "Abrir Switch File Hub"; Flags: nowait postinstall skipifsilent
