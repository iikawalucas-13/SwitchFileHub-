import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import '../core/models.dart';

class FtpReply {
  FtpReply(this.code, this.text);
  final int code;
  final String text;
  bool get positivePreliminary => code >= 100 && code < 200;
  bool get isOk => code >= 200 && code < 300;
  bool get intermediate => code >= 300 && code < 400;
}

class FtpProtocolException implements Exception {
  FtpProtocolException(this.reply, [this.context]);
  final FtpReply reply;
  final String? context;

  @override
  String toString() {
    final base = switch (reply.code) {
      530 => 'Usuário ou senha recusados pelo servidor.',
      550 => 'Arquivo/pasta não encontrado ou sem permissão (550).',
      553 => 'Nome de arquivo não permitido pelo servidor (553).',
      421 => 'Servidor indisponível ou muitas conexões (421). '
          'Feche conexões extras e tente novamente.',
      425 || 426 => 'A transferência de dados falhou (${reply.code}).',
      452 || 552 => 'Sem espaço no microSD (${reply.code}).',
      _ => 'Resposta do servidor: ${reply.code} ${reply.text}',
    };
    return context == null ? base : '$context: $base';
  }
}

typedef ByteProgress = void Function(int transferred, int total);

/// Cliente FTP mínimo sobre dart:io: modo passivo, TYPE I, MLSD/LIST, STOR/RETR
/// em fluxo (sem carregar o arquivo na memória) e aborto imediato.
class FtpClient {
  FtpClient(this.host, this.port,
      {this.timeout = const Duration(seconds: 15)});

  final String host;
  final int port;
  final Duration timeout;

  Socket? _ctl;
  Socket? _data;
  StreamSubscription<String>? _sub;
  final List<String> _lines = [];
  Completer<void>? _wake;
  bool _closed = true;

  bool get isOpen => !_closed;

  // ----------------------------------------------------------- controle

  Future<void> connect(String user, String pass) async {
    await close();
    _lines.clear();
    _closed = false;
    final s = await Socket.connect(host, port, timeout: timeout);
    _ctl = s;
    s.setOption(SocketOption.tcpNoDelay, true);
    _sub = const Utf8Decoder(allowMalformed: true)
        .bind(s)
        .transform(const LineSplitter())
        .listen((l) {
      _lines.add(l);
      _notify();
    }, onError: (Object _) {
      _closed = true;
      _notify();
    }, onDone: () {
      _closed = true;
      _notify();
    }, cancelOnError: false);

    final greet = await _readReply();
    if (greet.code != 220) throw FtpProtocolException(greet, 'Saudação');
    var r = await command('USER ${user.isEmpty ? 'anonymous' : user}');
    if (r.intermediate) {
      r = await command('PASS $pass', secret: true);
    }
    if (r.code != 230) throw FtpProtocolException(r, 'Login');
    await command('TYPE I');
    try {
      await command('OPTS UTF8 ON'); // opcional
    } catch (_) {}
  }

  void _notify() {
    final w = _wake;
    if (w != null && !w.isCompleted) w.complete();
  }

  Future<FtpReply> _readReply({Duration? wait}) async {
    int? code;
    var multi = false;
    final sb = StringBuffer();
    while (true) {
      while (_lines.isEmpty) {
        if (_closed) {
          throw const SocketException('Conexão encerrada pelo servidor');
        }
        final w = _wake = Completer<void>();
        await w.future.timeout(wait ?? timeout, onTimeout: () {
          throw TimeoutException('Tempo esgotado aguardando o servidor');
        });
      }
      final line = _lines.removeAt(0);
      if (code == null) {
        if (line.length >= 3 && int.tryParse(line.substring(0, 3)) != null) {
          code = int.parse(line.substring(0, 3));
          multi = line.length > 3 && line[3] == '-';
          sb.write(line.length > 4 ? line.substring(4) : '');
          if (!multi) return FtpReply(code, sb.toString());
        }
        continue;
      }
      if (line.startsWith('$code ')) {
        sb.write('\n${line.substring(4)}');
        return FtpReply(code, sb.toString());
      }
      sb.write('\n$line');
    }
  }

  /// Envia um comando. Rejeita CR/LF (injeção de comandos).
  Future<FtpReply> command(String cmd, {bool secret = false}) async {
    if (cmd.contains('\r') || cmd.contains('\n')) {
      throw ArgumentError('Comando FTP inválido.');
    }
    final s = _ctl;
    if (s == null || _closed) {
      throw const SocketException('Conexão encerrada');
    }
    s.add(utf8.encode('$cmd\r\n'));
    return _readReply();
  }

  Future<FtpReply> _expect(String cmd, List<int> codes,
      {String? context}) async {
    final r = await command(cmd);
    if (!codes.contains(r.code)) throw FtpProtocolException(r, context);
    return r;
  }

  /// Aborta tudo imediatamente (usado no cancelamento).
  Future<void> close() async {
    _closed = true;
    _notify();
    try {
      _data?.destroy();
    } catch (_) {}
    _data = null;
    final s = _ctl;
    _ctl = null;
    try {
      await _sub?.cancel();
    } catch (_) {}
    _sub = null;
    try {
      s?.destroy();
    } catch (_) {}
  }

  /// Encerramento educado (QUIT) seguido de close().
  Future<void> quit() async {
    try {
      if (!_closed) {
        _ctl?.add(utf8.encode('QUIT\r\n'));
      }
    } catch (_) {}
    await close();
  }

  // ------------------------------------------------------- comandos simples

  Future<String> pwd() async {
    final r = await _expect('PWD', [257]);
    final m = RegExp(r'"((?:[^"]|"")*)"').firstMatch(r.text);
    return m == null ? '/' : m.group(1)!.replaceAll('""', '"');
  }

  Future<bool> cwd(String path) async => (await command('CWD $path')).isOk;
  Future<void> cdup() => _expect('CDUP', [200, 250]);
  Future<bool> mkd(String path) async =>
      (await command('MKD $path')).code == 257;
  Future<void> rmd(String path) => _expect('RMD $path', [250], context: 'Excluir pasta');
  Future<void> dele(String path) => _expect('DELE $path', [250], context: 'Excluir arquivo');

  Future<void> rename(String from, String to) async {
    await _expect('RNFR $from', [350], context: 'Renomear');
    await _expect('RNTO $to', [250], context: 'Renomear');
  }

  /// Tamanho do arquivo, ou null se não existe/não suportado.
  Future<int?> size(String path) async {
    final r = await command('SIZE $path');
    if (r.code == 213) return int.tryParse(r.text.trim());
    return null;
  }

  // ------------------------------------------------------------------ dados

  Future<Socket> _openPassive() async {
    final r = await _expect('PASV', [227], context: 'Modo passivo');
    final m = RegExp(r'(\d+),(\d+),(\d+),(\d+),(\d+),(\d+)').firstMatch(r.text);
    if (m == null) throw FtpProtocolException(r, 'Resposta PASV inválida');
    final port = int.parse(m.group(5)!) * 256 + int.parse(m.group(6)!);
    // Usa o host do controle (ignora o IP anunciado: evita NAT/bounce).
    final s = await Socket.connect(host, port, timeout: timeout);
    _data = s;
    return s;
  }

  Future<void> _finishData(Socket? d) async {
    try {
      d?.destroy();
    } catch (_) {}
    if (identical(_data, d)) _data = null;
  }

  Future<String> _readText(String cmd) async {
    final d = await _openPassive();
    try {
      final r1 = await command(cmd);
      if (!r1.positivePreliminary) throw FtpProtocolException(r1, 'Listagem');
      final bb = BytesBuilder(copy: false);
      await for (final chunk in d) {
        bb.add(chunk);
      }
      await _finishData(d);
      final r2 = await _readReply();
      if (!r2.isOk) throw FtpProtocolException(r2, 'Listagem');
      return const Utf8Decoder(allowMalformed: true).convert(bb.takeBytes());
    } finally {
      await _finishData(d);
    }
  }

  Future<List<RemoteEntry>> list({String? path, required bool mlsd}) async {
    final arg = (path == null || path.isEmpty) ? '' : ' $path';
    final text = await _readText('${mlsd ? 'MLSD' : 'LIST'}$arg');
    return mlsd ? parseMlsd(text) : parseList(text);
  }

  /// STOR em fluxo.
  Future<void> store(File file, String remotePath,
      {ByteProgress? onProgress}) async {
    final total = await file.length();
    final d = await _openPassive();
    try {
      final r1 = await command('STOR $remotePath');
      if (!r1.positivePreliminary) throw FtpProtocolException(r1, 'Envio');
      var sent = 0;
      await d.addStream(file.openRead().map((chunk) {
        sent += chunk.length;
        onProgress?.call(sent, total);
        return chunk;
      }));
      await d.flush();
      await d.close();
      await _finishData(d);
      final r2 = await _readReply(wait: const Duration(minutes: 2));
      if (!r2.isOk) throw FtpProtocolException(r2, 'Envio');
    } finally {
      await _finishData(d);
    }
  }

  /// RETR em fluxo para [target] (o chamador cuida do arquivo temporário).
  Future<void> retrieve(String remotePath, File target,
      {int? expectedSize, ByteProgress? onProgress}) async {
    final total = expectedSize ?? (await size(remotePath)) ?? 0;
    final d = await _openPassive();
    final sink = target.openWrite();
    try {
      final r1 = await command('RETR $remotePath');
      if (!r1.positivePreliminary) throw FtpProtocolException(r1, 'Download');
      var got = 0;
      await sink.addStream(d.map((Uint8List chunk) {
        got += chunk.length;
        onProgress?.call(got, total);
        return chunk;
      }));
      await sink.flush();
      await sink.close();
      await _finishData(d);
      final r2 = await _readReply(wait: const Duration(minutes: 2));
      if (!r2.isOk) throw FtpProtocolException(r2, 'Download');
      if (total > 0 && got != total) {
        throw FtpProtocolException(
            FtpReply(426, 'recebidos $got de $total bytes'), 'Download incompleto');
      }
    } catch (_) {
      try {
        await sink.close();
      } catch (_) {}
      rethrow;
    } finally {
      await _finishData(d);
    }
  }

  // ---------------------------------------------------------------- parsers

  static List<RemoteEntry> parseMlsd(String text) {
    final out = <RemoteEntry>[];
    for (final raw in const LineSplitter().convert(text)) {
      if (raw.trim().isEmpty) continue;
      final sp = raw.indexOf(' ');
      if (sp < 0) continue;
      final facts = <String, String>{};
      for (final f in raw.substring(0, sp).split(';')) {
        final eq = f.indexOf('=');
        if (eq > 0) {
          facts[f.substring(0, eq).toLowerCase()] = f.substring(eq + 1);
        }
      }
      final name = raw.substring(sp + 1);
      final type = (facts['type'] ?? '').toLowerCase();
      if (type == 'cdir' || type == 'pdir' || name == '.' || name == '..') {
        continue;
      }
      final isLink = (facts['unix.mode'] == null &&
              (facts['os.unix'] ?? '').toLowerCase().startsWith('slink')) ||
          type.startsWith('os.unix=slink');
      out.add(RemoteEntry(name, type == 'dir', int.tryParse(facts['size'] ?? ''),
          isLink: isLink));
    }
    return out;
  }

  static final RegExp _unix = RegExp(
      r'^([\-dlbcps])[rwxsStT\-]{9}[+@.]?\s+\d+\s+\S+\s+\S+\s+(\d+)\s+\S+\s+\S+\s+\S+\s+(.+)$');
  static final RegExp _dos = RegExp(
      r'^\d{2}-\d{2}-\d{2,4}\s+\d{1,2}:\d{2}(?:AM|PM)?\s+(<DIR>|\d+)\s+(.+)$',
      caseSensitive: false);

  static List<RemoteEntry> parseList(String text) {
    final out = <RemoteEntry>[];
    for (final raw in const LineSplitter().convert(text)) {
      final line = raw.trimRight();
      if (line.isEmpty || line.startsWith('total ')) continue;
      final u = _unix.firstMatch(line);
      if (u != null) {
        var name = u.group(3)!;
        final isLink = u.group(1) == 'l';
        if (isLink) {
          final i = name.indexOf(' -> ');
          if (i > 0) name = name.substring(0, i);
        }
        if (name == '.' || name == '..') continue;
        out.add(RemoteEntry(name, u.group(1) == 'd', int.tryParse(u.group(2)!),
            isLink: isLink));
        continue;
      }
      final d = _dos.firstMatch(line);
      if (d != null) {
        final isDir = d.group(1)!.toUpperCase() == '<DIR>';
        out.add(RemoteEntry(d.group(2)!, isDir,
            isDir ? null : int.tryParse(d.group(1)!)));
      }
    }
    return out;
  }
}
