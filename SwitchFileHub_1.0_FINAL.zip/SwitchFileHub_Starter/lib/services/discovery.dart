import 'dart:async';
import 'dart:convert';
import 'dart:io';

class FoundServer {
  FoundServer(this.host, this.port, this.banner);
  final String host;
  final int port;
  final String banner;
}

/// Hosts 1..254 da sub-rede /24 de [ip] (exceto o próprio [ip]).
List<String> subnetHosts(String ip) {
  final p = ip.split('.');
  if (p.length != 4) return [];
  final base = '${p[0]}.${p[1]}.${p[2]}';
  return [
    for (var i = 1; i <= 254; i++)
      if ('$base.$i' != ip) '$base.$i',
  ];
}

/// Procura servidores FTP (banner "220") na rede local, na [port] dada
/// (FTPD usa 5000). Varre só sub-redes privadas /24 das interfaces ativas.
Future<List<FoundServer>> discoverFtpServers({
  int port = 5000,
  Duration timeout = const Duration(milliseconds: 500),
  void Function(double progress)? onProgress,
}) async {
  final ifs = await NetworkInterface.list(
      type: InternetAddressType.IPv4, includeLoopback: false);
  final targets = <String>{};
  for (final i in ifs) {
    for (final a in i.addresses) {
      if (a.isLinkLocal) continue;
      final ip = a.address;
      final priv = ip.startsWith('192.168.') ||
          ip.startsWith('10.') ||
          RegExp(r'^172\.(1[6-9]|2\d|3[01])\.').hasMatch(ip);
      if (priv) targets.addAll(subnetHosts(ip));
    }
  }
  final list = targets.toList();
  final found = <FoundServer>[];
  var done = 0;

  Future<void> probe(String host) async {
    Socket? s;
    try {
      s = await Socket.connect(host, port, timeout: timeout);
      final line = await const Utf8Decoder(allowMalformed: true)
          .bind(s)
          .transform(const LineSplitter())
          .first
          .timeout(const Duration(seconds: 1));
      if (line.startsWith('220')) {
        found.add(FoundServer(host, port, line.substring(3).trim()));
      }
    } catch (_) {
    } finally {
      s?.destroy();
      done++;
      onProgress?.call(list.isEmpty ? 1 : done / list.length);
    }
  }

  for (var i = 0; i < list.length; i += 64) {
    await Future.wait(list.sublist(i, i + 64 > list.length ? list.length : i + 64).map(probe));
  }
  return found;
}
