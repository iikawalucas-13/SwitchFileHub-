import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';

import '../core/models.dart';
import 'ftp_session.dart';

class _Cancelled implements Exception {}

/// Fila de transferências: blocos (streaming), progresso, velocidade, ETA,
/// cancelamento, novas tentativas e recuperação de conexão.
class TransferManager extends ChangeNotifier {
  TransferManager({
    required this.settings,
    required this.onFinished,
    this.maxConcurrent = 2,
    this.maxRetries = 2,
  });

  final ConnectionSettings Function() settings;
  final void Function(TransferJob job) onFinished;
  int maxConcurrent;
  final int maxRetries;

  final List<TransferJob> jobs = [];
  int _nextId = 1;
  int _running = 0;
  Timer? _notifyTimer;

  int get nextId => _nextId++;
  int get activeCount => jobs
      .where((j) =>
          j.state == TransferState.running || j.state == TransferState.queued)
      .length;
  int get completedCount =>
      jobs.where((j) => j.state == TransferState.done).length;

  void _notifyThrottled() {
    if (_notifyTimer != null) return;
    _notifyTimer = Timer(const Duration(milliseconds: 200), () {
      _notifyTimer = null;
      notifyListeners();
    });
  }

  void enqueue(Iterable<TransferJob> newJobs) {
    jobs.addAll(newJobs);
    notifyListeners();
    _pump();
  }

  void _pump() {
    for (final j in jobs) {
      if (_running >= maxConcurrent) break;
      if (j.state == TransferState.queued) {
        _running++;
        unawaited(_execute(j).whenComplete(() {
          _running--;
          _pump();
        }));
      }
    }
  }

  void cancel(TransferJob j) {
    if (j.isFinished) return;
    if (j.state == TransferState.queued) {
      j.state = TransferState.cancelled;
      notifyListeners();
      onFinished(j);
      return;
    }
    if (!j.cancelSignal.isCompleted) j.cancelSignal.complete();
  }

  void cancelAll() {
    for (final j in List.of(jobs)) {
      cancel(j);
    }
  }

  void retry(TransferJob j) {
    if (j.state != TransferState.failed && j.state != TransferState.cancelled) {
      return;
    }
    j.state = TransferState.queued;
    j.transferred = 0;
    j.writing = false;
    j.error = null;
    j.speed = 0;
    j.eta = null;
    j.cancelSignal = Completer<void>();
    notifyListeners();
    _pump();
  }

  void clearFinished() {
    jobs.removeWhere((j) => j.isFinished);
    notifyListeners();
  }

  Future<void> _execute(TransferJob job) async {
    job.state = TransferState.running;
    job.startedAt = DateTime.now();
    job.attempts = 0;
    notifyListeners();

    final session = FtpSession(settings());
    final cancelled = job.cancelSignal.future.then<void>((_) {
      throw _Cancelled();
    });

    try {
      while (true) {
        job.attempts++;
        job.transferred = 0;
        try {
          await Future.any<void>([_attempt(job, session), cancelled]);
          break;
        } on _Cancelled {
          rethrow;
        } catch (e) {
          final retriable = FtpSession.isNetworkError(e) &&
              job.attempts <= maxRetries &&
              !job.cancelSignal.isCompleted;
          if (!retriable) rethrow;
          await session.disconnect();
          await Future.any<void>(
              [Future<void>.delayed(const Duration(seconds: 2)), cancelled]);
        }
      }
    } on _Cancelled {
      await session.disconnect();
      await _cleanupPartial(job);
      job.state = TransferState.cancelled;
    } catch (e) {
      job.state = TransferState.failed;
      job.error = session.friendly(e);
    } finally {
      await session.disconnect();
      job.speed = 0;
      job.eta = null;
      notifyListeners();
      onFinished(job);
    }
  }

  Future<void> _attempt(TransferJob job, FtpSession session) async {
    await session.connect();
    final sw = Stopwatch()..start();
    var lastMs = 0;
    var lastBytes = 0;
    void progress(int done, int total) {
      job.transferred = done;
      if (job.direction == TransferDirection.upload) job.writing = true;
      if (total > 0) job.totalBytes = total;
      final ms = sw.elapsedMilliseconds;
      if (ms - lastMs >= 500) {
        final inst = (done - lastBytes) * 1000 / (ms - lastMs);
        job.speed = job.speed == 0 ? inst : job.speed * 0.7 + inst * 0.3;
        lastMs = ms;
        lastBytes = done;
        final t = job.totalBytes;
        job.eta = (t != null && t > 0 && job.speed > 1)
            ? Duration(seconds: ((t - done) / job.speed).round())
            : null;
      }
      _notifyThrottled();
    }

    final bool transferredOk;
    if (job.direction == TransferDirection.upload) {
      final file = File(job.localPath);
      if (!await file.exists()) {
        throw FtpException('O arquivo local não foi encontrado.');
      }
      job.totalBytes = await file.length();
      transferredOk = await session.upload(
        file,
        job.remoteDir,
        job.remoteName,
        overwrite: job.overwrite,
        onProgress: progress,
      );
    } else {
      transferredOk = await session.download(
        job.remoteDir,
        job.remoteName,
        File(job.localPath),
        overwrite: job.overwrite,
        expectedSize: job.totalBytes,
        onProgress: progress,
      );
    }
    job.state =
        transferredOk ? TransferState.done : TransferState.skipped;
    if (transferredOk && job.totalBytes != null) {
      job.transferred = job.totalBytes!;
    }
  }

  Future<void> _cleanupPartial(TransferJob job) async {
    try {
      if (job.direction == TransferDirection.download) {
        final part = File('${job.localPath}.sfhpart');
        if (await part.exists()) await part.delete();
      } else if (job.writing) {
        // Envio incompleto: remove somente o arquivo parcial criado por este
        // app, para não deixar um arquivo corrompido no microSD.
        final s = FtpSession(settings());
        try {
          await s.connect();
          await s.changeDirectory(job.remoteDir);
          await s.deleteFile(job.remoteName);
        } finally {
          await s.disconnect();
        }
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    _notifyTimer?.cancel();
    super.dispose();
  }
}
