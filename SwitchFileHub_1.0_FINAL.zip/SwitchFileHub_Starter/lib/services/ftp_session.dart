import 'dart:async';
import 'dart:io';

import '../core/format.dart';
import '../core/models.dart';
import 'ftp_client.dart';

export 'ftp_client.dart' show ByteProgress;

class FtpException implements Exception {
  FtpException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Sessão de alto nível sobre [FtpClient]: reconexão automática, validação de
/// nomes/caminhos e operações de arquivo. Cada transferência usa a sua própria
/// sessão, então cancelar uma não afeta a navegação nem as outras.
class FtpSession {
  FtpSession(this.settings);

  final ConnectionSettings settings;
  FtpClient? _client;
  bool _mlsd = true;
  String _cwd = '/';

  bool get connected => _client != null && _client!.isOpen;
  String get cwd => _cwd;

  static bool isNetworkError(Object e) {
    if (e is SocketException || e is TimeoutException) return true;
    if (e is FtpProtocolException) return e.reply.code == 421;
    return false;
  }

  String friendly(Object e) {
    if (e is TimeoutException) {
      return 'Tempo esgotado. Verifique IP, porta e se o FTPD está aberto.';
    }
    if (e is SocketException) {
      return 'Sem conexão com o Switch (${e.message}).';
    }
    return redact(e.toString().replaceFirst('Exception: ', ''), settings.password);
  }

  Future<void> connect() async {
    await disconnect();
    _mlsd = settings.listMode != ListMode.list;
    final c = FtpClient(settings.host.trim(), settings.port,
        timeout: Duration(seconds: settings.timeoutSeconds));
    try {
      await c.connect(settings.user.trim(), settings.password);
      _client = c;
      _cwd = await c.pwd();
    } catch (e) {
      await c.close();
      _client = null;
      throw FtpException(friendly(e));
    }
  }

  /// Fecha a conexão (também usado para abortar uma transferência em curso).
  Future<void> disconnect() async {
    final c = _client;
    _client = null;
    if (c != null) await c.quit();
  }

  FtpClient _require() {
    final c = _client;
    if (c == null || !c.isOpen) {
      throw FtpException('Não conectado ao Switch.');
    }
    return c;
  }

  /// Reconecta e restaura a pasta atual (recuperação de conexão).
  Future<void> reconnect() async {
    final keep = _cwd;
    await connect();
    if (keep != '/') {
      await _require().cwd(keep);
      _cwd = await _require().pwd();
    }
  }

  /// Executa [op]; se falhar por problema de rede, reconecta uma vez e repete.
  Future<T> _run<T>(Future<T> Function(FtpClient c) op) async {
    try {
      return await op(_require());
    } catch (e) {
      if (!isNetworkError(e)) rethrow;
      try {
        await reconnect();
      } catch (_) {
        throw FtpException('Conexão perdida e a reconexão falhou. ${friendly(e)}');
      }
      return await op(_require());
    }
  }

  // ---------------------------------------------------------------- navegação

  Future<String> currentDirectory() => _run((c) async => _cwd = await c.pwd());

  Future<List<RemoteEntry>> list() => _run((c) async {
        List<RemoteEntry> raw;
        try {
          raw = await c.list(mlsd: _mlsd);
        } on FtpProtocolException catch (e) {
          // Servidor sem MLSD (500/501/502/504): usa LIST no modo automático.
          if (_mlsd &&
              settings.listMode == ListMode.auto &&
              (e.reply.code >= 500 && e.reply.code < 505)) {
            _mlsd = false;
            raw = await c.list(mlsd: false);
          } else {
            rethrow;
          }
        }
        final out = raw
            .where((e) => e.name != '.' && e.name != '..' && e.name.isNotEmpty)
            .toList();
        out.sort((a, b) {
          if (a.isDir != b.isDir) return a.isDir ? -1 : 1;
          return a.name.toLowerCase().compareTo(b.name.toLowerCase());
        });
        return out;
      });

  /// Muda de pasta. [path] pode ser absoluto ("/switch"), nome simples ou "..".
  Future<void> changeDirectory(String path) async {
    if (path != '..') {
      if (path.startsWith('/')) {
        if (normalizeRemotePath(path) == null) {
          throw FtpException('Caminho inválido.');
        }
      } else if (validateName(path) != null) {
        throw FtpException('Nome de pasta inválido.');
      }
    }
    await _run((c) async {
      if (path == '..') {
        await c.cdup();
      } else if (!await c.cwd(path)) {
        throw FtpException('Não foi possível abrir "$path".');
      }
      _cwd = await c.pwd();
    });
  }

  // ----------------------------------------------------------------- operações

  String _abs(String name) => joinRemote(_cwd, name);

  Future<void> makeDirectory(String name) async {
    final err = validateName(name);
    if (err != null) throw FtpException(err);
    await _run((c) async {
      final n = name.trim();
      final existing = await list();
      if (existing.any((e) => e.name == n)) {
        throw FtpException('Já existe um item chamado "$n".');
      }
      if (!await c.mkd(_abs(n))) {
        throw FtpException('O servidor não confirmou a criação da pasta.');
      }
    });
  }

  Future<void> rename(String oldName, String newName) async {
    final err = validateName(newName);
    if (err != null) throw FtpException(err);
    if (validateName(oldName) != null) throw FtpException('Nome inválido.');
    await _run((c) async {
      final n = newName.trim();
      final existing = await list();
      if (existing.any((e) => e.name == n)) {
        throw FtpException('Já existe um item chamado "$n".');
      }
      await c.rename(_abs(oldName), _abs(n));
    });
  }

  Future<void> deleteFile(String name) async {
    if (validateName(name) != null) throw FtpException('Nome inválido.');
    await _run((c) => c.dele(_abs(name)));
  }

  /// Apaga a pasta e todo o seu conteúdo. A UI deve confirmar antes.
  Future<void> deleteDirectory(String name) async {
    if (validateName(name) != null) throw FtpException('Nome inválido.');
    final root = _abs(name);

    Future<void> rm(String dir, int depth) async {
      if (depth > 32) throw FtpException('Pasta aninhada demais.');
      final entries = await _run((c) => c.list(path: dir, mlsd: _mlsd));
      for (final e in entries) {
        if (validateName(e.name) != null) continue;
        final child = joinRemote(dir, e.name);
        if (e.isDir) {
          await rm(child, depth + 1);
        } else {
          await _run((c) => c.dele(child));
        }
      }
      await _run((c) => c.rmd(dir));
    }

    await rm(root, 0);
  }

  Future<bool> fileExists(String remoteDir, String name) => _run((c) async {
        final path = joinRemote(remoteDir, name);
        final s = await c.size(path);
        if (s != null) return true;
        final entries = await c.list(path: remoteDir, mlsd: _mlsd);
        return entries.any((e) => e.name == name);
      });

  // ------------------------------------------------------------ transferências

  Future<void> _mkdirs(FtpClient c, String dir) async {
    final norm = normalizeRemotePath(dir);
    if (norm == null) throw FtpException('Caminho remoto inválido.');
    var acc = '';
    for (final seg in norm.split('/').where((s) => s.isNotEmpty)) {
      acc = '$acc/$seg';
      if (!await c.cwd(acc)) {
        await c.mkd(acc); // pode falhar se outra transferência criou antes
        if (!await c.cwd(acc)) {
          throw FtpException('Não foi possível acessar ou criar "$acc".');
        }
      }
    }
  }

  /// Envia [file]. Retorna false se já existia e [overwrite] é false.
  Future<bool> upload(
    File file,
    String remoteDir,
    String remoteName, {
    required bool overwrite,
    ByteProgress? onProgress,
  }) async {
    final err = validateName(remoteName);
    if (err != null) throw FtpException(err);
    final c = _require();
    await _mkdirs(c, remoteDir);
    final target = joinRemote(normalizeRemotePath(remoteDir)!, remoteName);
    if (!overwrite && (await c.size(target)) != null) return false;
    final total = await file.length();
    onProgress?.call(0, total); // sinaliza que a escrita remota vai começar
    await c.store(file, target, onProgress: onProgress);
    onProgress?.call(total, total);
    return true;
  }

  /// Baixa para [target] via "<target>.sfhpart" e só renomeia ao terminar,
  /// para nunca deixar um arquivo parcial com o nome final.
  /// Retorna false se o destino existe e [overwrite] é false.
  Future<bool> download(
    String remoteDir,
    String remoteName,
    File target, {
    required bool overwrite,
    ByteProgress? onProgress,
    int? expectedSize,
  }) async {
    if (validateName(remoteName) != null) {
      throw FtpException('O servidor retornou um nome inválido: "$remoteName".');
    }
    final norm = normalizeRemotePath(remoteDir);
    if (norm == null) throw FtpException('Caminho remoto inválido.');
    if (await target.exists() && !overwrite) return false;
    final c = _require();
    await target.parent.create(recursive: true);
    final part = File('${target.path}.sfhpart');
    if (await part.exists()) await part.delete();
    try {
      await c.retrieve(joinRemote(norm, remoteName), part,
          expectedSize: expectedSize, onProgress: onProgress);
      if (await target.exists()) await target.delete();
      await part.rename(target.path);
    } catch (_) {
      try {
        if (await part.exists()) await part.delete();
      } catch (_) {}
      rethrow;
    }
    return true;
  }

  /// Lista recursivamente os arquivos de [remoteDir] (para baixar pastas).
  Future<List<RemoteFileInfo>> listRecursive(String remoteDir,
      {int maxDepth = 32}) async {
    final out = <RemoteFileInfo>[];
    Future<void> walk(String dir, List<String> rel, int depth) async {
      if (depth > maxDepth) return;
      final entries = await _run((c) => c.list(path: dir, mlsd: _mlsd));
      for (final e in entries) {
        if (validateName(e.name) != null) continue; // nome suspeito: ignora
        if (e.isDir) {
          await walk(joinRemote(dir, e.name), [...rel, e.name], depth + 1);
        } else if (!e.isLink) {
          out.add(RemoteFileInfo([...rel, e.name], e.size));
        }
      }
    }

    await walk(remoteDir, const [], 0);
    return out;
  }

  /// Teste de conexão sem manter sessão aberta.
  static Future<String> test(ConnectionSettings s) async {
    final sw = Stopwatch()..start();
    final session = FtpSession(s);
    try {
      await session.connect();
      final dir = await session.currentDirectory();
      final items = await session.list();
      sw.stop();
      return 'Conexão OK em ${sw.elapsedMilliseconds} ms. '
          'Pasta "$dir" com ${items.length} item(ns).';
    } finally {
      await session.disconnect();
    }
  }
}
