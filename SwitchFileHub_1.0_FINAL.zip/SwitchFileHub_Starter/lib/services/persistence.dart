import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../core/models.dart';

/// Configurações e histórico. A SENHA NUNCA é gravada.
class Persistence {
  Persistence(this._prefs);
  final SharedPreferences _prefs;

  static Future<Persistence> open() async =>
      Persistence(await SharedPreferences.getInstance());

  static const _maxHistory = 500;

  ConnectionSettings loadConnection() => ConnectionSettings(
        host: _prefs.getString('host') ?? '',
        port: _prefs.getInt('port') ?? 5000,
        user: _prefs.getString('user') ?? '',
        timeoutSeconds: _prefs.getInt('timeout') ?? 15,
        listMode: ListMode.values.firstWhere(
          (m) => m.name == _prefs.getString('listMode'),
          orElse: () => ListMode.auto,
        ),
      );

  Future<void> saveConnection(ConnectionSettings s) async {
    await _prefs.setString('host', s.host);
    await _prefs.setInt('port', s.port);
    await _prefs.setString('user', s.user);
    await _prefs.setInt('timeout', s.timeoutSeconds);
    await _prefs.setString('listMode', s.listMode.name);
  }

  String? get downloadDir => _prefs.getString('downloadDir');
  Future<void> setDownloadDir(String? v) => v == null
      ? _prefs.remove('downloadDir')
      : _prefs.setString('downloadDir', v);

  int get maxConcurrent => (_prefs.getInt('maxConcurrent') ?? 2).clamp(1, 3);
  Future<void> setMaxConcurrent(int v) => _prefs.setInt('maxConcurrent', v);

  List<HistoryEntry> loadHistory() {
    final raw = _prefs.getString('history');
    if (raw == null) return [];
    try {
      final list = jsonDecode(raw) as List;
      return list.map(HistoryEntry.fromJson).whereType<HistoryEntry>().toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> saveHistory(List<HistoryEntry> h) {
    final trimmed =
        h.length > _maxHistory ? h.sublist(h.length - _maxHistory) : h;
    return _prefs.setString(
        'history', jsonEncode(trimmed.map((e) => e.toJson()).toList()));
  }
}
