import 'package:flutter/material.dart';

import 'pages/about_page.dart';
import 'pages/connect_page.dart';
import 'pages/devices_page.dart';
import 'pages/files_page.dart';
import 'pages/history_page.dart';
import 'pages/home_page.dart';
import 'pages/settings_page.dart';
import 'pages/transfers_page.dart';
import 'theme.dart';

class _Dest {
  const _Dest(this.label, this.icon, this.page);
  final String label;
  final IconData icon;
  final Widget Function(void Function(int) go) page;
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;

  void _go(int i) => setState(() => _index = i);

  late final List<_Dest> _dests = [
    _Dest('Início', Icons.home_outlined, (go) => HomePage(go: go)),
    _Dest('Conectar Switch', Icons.link, (go) => ConnectPage(go: go)),
    _Dest('Gerenciador de arquivos', Icons.folder_copy_outlined,
        (go) => const FilesPage()),
    _Dest('Transferências', Icons.swap_vert, (go) => const TransfersPage()),
    _Dest('Histórico', Icons.history, (go) => const HistoryPage()),
    _Dest('Dispositivos', Icons.devices_other, (go) => DevicesPage(go: go)),
    _Dest('Configurações', Icons.settings_outlined,
        (go) => const SettingsPage()),
    _Dest('Sobre', Icons.info_outline, (go) => const AboutPage()),
  ];

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final wide = MediaQuery.of(context).size.width >= 900;
    final active = app.transfers.activeCount;
    final body = AnimatedSwitcher(
      duration: const Duration(milliseconds: 180),
      child: KeyedSubtree(
        key: ValueKey(_index),
        child: _dests[_index].page(_go),
      ),
    );

    Widget icon(int i) {
      final w = Icon(_dests[i].icon);
      if (i == 3 && active > 0) {
        return Badge(label: Text('$active'), child: w);
      }
      return w;
    }

    if (wide) {
      return Scaffold(
        body: Row(
          children: [
            NavigationRail(
              extended: true,
              minExtendedWidth: 240,
              selectedIndex: _index,
              onDestinationSelected: _go,
              leading: const Padding(
                padding: EdgeInsets.fromLTRB(16, 20, 16, 16),
                child: _Brand(),
              ),
              destinations: [
                for (var i = 0; i < _dests.length; i++)
                  NavigationRailDestination(
                      icon: icon(i), label: Text(_dests[i].label)),
              ],
            ),
            const VerticalDivider(width: 1),
            Expanded(child: body),
          ],
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(_dests[_index].label)),
      drawer: NavigationDrawer(
        selectedIndex: _index,
        onDestinationSelected: (i) {
          Navigator.pop(context);
          _go(i);
        },
        children: [
          const Padding(
              padding: EdgeInsets.fromLTRB(24, 24, 16, 12), child: _Brand()),
          for (var i = 0; i < _dests.length; i++)
            NavigationDrawerDestination(
                icon: icon(i), label: Text(_dests[i].label)),
        ],
      ),
      body: body,
    );
  }
}

class _Brand extends StatelessWidget {
  const _Brand();
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [kBlue, kPurple]),
            borderRadius: BorderRadius.circular(10),
          ),
          child: const Icon(Icons.gamepad, color: Colors.white, size: 22),
        ),
        const SizedBox(width: 10),
        const Text('Switch File Hub',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
      ],
    );
  }
}
