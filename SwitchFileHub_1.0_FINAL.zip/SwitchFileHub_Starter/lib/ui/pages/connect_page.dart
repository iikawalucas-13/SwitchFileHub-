import 'package:flutter/material.dart';

import '../../core/models.dart';
import '../../services/discovery.dart';
import '../../state/app_controller.dart';
import '../theme.dart';

class ConnectPage extends StatefulWidget {
  const ConnectPage({super.key, required this.go});
  final void Function(int) go;
  @override
  State<ConnectPage> createState() => _ConnectPageState();
}

class _ConnectPageState extends State<ConnectPage> {
  late final TextEditingController _host;
  late final TextEditingController _port;
  late final TextEditingController _user;
  final _pass = TextEditingController();
  bool _testing = false;
  String? _testResult;
  bool _testOk = false;
  bool _showPass = false;
  bool _scanning = false;
  double _scanProgress = 0;
  List<FoundServer>? _found;

  Future<void> _scan() async {
    final port = int.tryParse(_port.text.trim()) ?? 5000;
    setState(() {
      _scanning = true;
      _scanProgress = 0;
      _found = null;
    });
    try {
      final r = await discoverFtpServers(
          port: port,
          onProgress: (v) {
            if (mounted) setState(() => _scanProgress = v);
          });
      if (!mounted) return;
      setState(() => _found = r);
      if (r.length == 1) _host.text = r.first.host;
    } catch (e) {
      if (mounted) showMsg(context, 'Falha ao procurar na rede: $e');
    } finally {
      if (mounted) setState(() => _scanning = false);
    }
  }

  @override
  void initState() {
    super.initState();
    // AppScope.of não pode ser usado em initState; lê no didChangeDependencies.
    _host = TextEditingController();
    _port = TextEditingController(text: '5000');
    _user = TextEditingController();
  }

  bool _loaded = false;
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_loaded) return;
    _loaded = true;
    final s = AppScope.of(context).settings;
    _host.text = s.host;
    _port.text = '${s.port}';
    _user.text = s.user;
  }

  @override
  void dispose() {
    _host.dispose();
    _port.dispose();
    _user.dispose();
    _pass.dispose();
    super.dispose();
  }

  ConnectionSettings? _read(AppController app) {
    final host = _host.text.trim();
    final port = int.tryParse(_port.text.trim());
    final validHost = RegExp(r'^[A-Za-z0-9.\-]+$').hasMatch(host);
    if (!validHost || port == null || port < 1 || port > 65535) {
      showMsg(context, 'Informe um IP/host e uma porta (1–65535) válidos.');
      return null;
    }
    final s = app.settings.copy()
      ..host = host
      ..port = port
      ..user = _user.text.trim()
      ..password = _pass.text;
    return s;
  }

  Future<void> _test(AppController app) async {
    final s = _read(app);
    if (s == null) return;
    setState(() {
      _testing = true;
      _testResult = null;
    });
    try {
      final r = await app.testConnection(s);
      if (!mounted) return;
      setState(() {
        _testOk = true;
        _testResult = r;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _testOk = false;
        _testResult = 'Falha: $e';
      });
    } finally {
      if (mounted) setState(() => _testing = false);
    }
  }

  Future<void> _connect(AppController app) async {
    final s = _read(app);
    if (s == null) return;
    await app.connect(s);
    if (!mounted) return;
    if (app.connected) widget.go(2);
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final connected = app.connected;
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 560),
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text(app.status,
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: connected ? Colors.greenAccent : Colors.white70)),
            const SizedBox(height: 16),
            TextField(
              controller: _host,
              enabled: !connected && !app.busy,
              keyboardType: TextInputType.url,
              decoration: const InputDecoration(
                labelText: 'Endereço IP do Switch',
                hintText: 'Ex.: 192.168.1.25',
                prefixIcon: Icon(Icons.wifi),
              ),
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: (connected || app.busy || _scanning) ? null : _scan,
                icon: const Icon(Icons.radar),
                label: Text(_scanning
                    ? 'Procurando… ${(_scanProgress * 100).round()}%'
                    : 'Procurar Switch na rede'),
              ),
            ),
            if (_scanning) LinearProgressIndicator(value: _scanProgress),
            if (_found != null)
              _found!.isEmpty
                  ? const Padding(
                      padding: EdgeInsets.symmetric(vertical: 6),
                      child: Text(
                          'Nenhum servidor FTP encontrado. Confira se o ftpd está aberto e se a porta está correta.',
                          style: TextStyle(color: Colors.amber)))
                  : Column(children: [
                      for (final f in _found!)
                        Card(
                          child: ListTile(
                            leading: const Icon(Icons.videogame_asset),
                            title: Text('${f.host}:${f.port}'),
                            subtitle: Text(f.banner),
                            onTap: () => setState(() => _host.text = f.host),
                          ),
                        ),
                    ]),
            const SizedBox(height: 12),
            TextField(
              controller: _port,
              enabled: !connected && !app.busy,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Porta FTP (FTPD usa 5000)',
                prefixIcon: Icon(Icons.settings_ethernet),
              ),
            ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: TextField(
                  controller: _user,
                  enabled: !connected && !app.busy,
                  decoration: const InputDecoration(
                    labelText: 'Usuário (opcional)',
                    prefixIcon: Icon(Icons.person_outline),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: _pass,
                  enabled: !connected && !app.busy,
                  obscureText: !_showPass,
                  decoration: InputDecoration(
                    labelText: 'Senha (opcional)',
                    prefixIcon: const Icon(Icons.lock_outline),
                    suffixIcon: IconButton(
                      icon: Icon(
                          _showPass ? Icons.visibility_off : Icons.visibility),
                      onPressed: () => setState(() => _showPass = !_showPass),
                    ),
                  ),
                ),
              ),
            ]),
            const SizedBox(height: 6),
            const Text(
              'Deixe usuário e senha em branco para acesso anônimo (padrão do FTPD). '
              'A senha fica só na memória e nunca é salva.',
              style: TextStyle(color: Colors.white54, fontSize: 12),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              alignment: WrapAlignment.center,
              children: [
                OutlinedButton.icon(
                  onPressed: (connected || app.busy || _testing)
                      ? null
                      : () => _test(app),
                  icon: _testing
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.network_check),
                  label: const Text('Testar conexão'),
                ),
                if (!connected)
                  FilledButton.icon(
                    onPressed:
                        (app.busy || _testing) ? null : () => _connect(app),
                    icon: app.busy
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.link),
                    label: Text(app.busy ? 'Conectando...' : 'Conectar'),
                  )
                else
                  FilledButton.icon(
                    style: FilledButton.styleFrom(
                        backgroundColor: Colors.redAccent),
                    onPressed: app.busy ? null : app.disconnect,
                    icon: const Icon(Icons.link_off),
                    label: const Text('Desconectar'),
                  ),
              ],
            ),
            if (_testResult != null) ...[
              const SizedBox(height: 14),
              Card(
                child: ListTile(
                  leading: Icon(_testOk ? Icons.check_circle : Icons.error,
                      color: _testOk ? Colors.greenAccent : Colors.redAccent),
                  title: Text(_testResult!),
                ),
              ),
            ],
            const SizedBox(height: 20),
            const Text(
              'O FTP tradicional não é criptografado. Use somente em rede Wi-Fi '
              'local confiável e nunca exponha a porta à internet.',
              style: TextStyle(color: Colors.white54, fontSize: 12),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
