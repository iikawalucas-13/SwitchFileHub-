import 'package:flutter/material.dart';

import '../../state/app_controller.dart';
import '../theme.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.go});
  final void Function(int) go;

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final ok = app.connected;
    final color = switch (app.link) {
      LinkState.connected => Colors.greenAccent,
      LinkState.connecting => Colors.amber,
      LinkState.error => Colors.redAccent,
      LinkState.disconnected => Colors.white54,
    };
    final done = app.transfers.completedCount;
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Icon(Icons.circle, color: color, size: 14),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        ok ? 'Conectado ao Switch' : 'Switch não conectado',
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 4),
                      Text(app.status,
                          style: const TextStyle(color: Colors.white70)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            _Stat('IP do Switch',
                app.settings.host.isEmpty ? '—' : app.settings.host,
                Icons.wifi),
            _Stat('Estado do FTP', ok ? 'Ativo (porta ${app.settings.port})' : 'Sem sessão',
                Icons.dns_outlined),
            const _Stat('Espaço disponível', 'Não informado pelo servidor',
                Icons.sd_storage_outlined),
            _Stat('Arquivos transferidos', '$done nesta sessão',
                Icons.task_alt),
            _Stat('Em andamento', '${app.transfers.activeCount}',
                Icons.sync),
          ],
        ),
        const SizedBox(height: 20),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            if (!ok)
              FilledButton.icon(
                  onPressed: () => go(1),
                  icon: const Icon(Icons.link),
                  label: const Text('Conectar ao Switch')),
            FilledButton.tonalIcon(
                onPressed: ok ? () => go(2) : null,
                icon: const Icon(Icons.upload_file),
                label: const Text('Enviar arquivos')),
            FilledButton.tonalIcon(
                onPressed: ok ? () => go(2) : null,
                icon: const Icon(Icons.download),
                label: const Text('Baixar arquivos')),
            OutlinedButton.icon(
                onPressed: () => go(3),
                icon: const Icon(Icons.swap_vert),
                label: const Text('Ver transferências')),
          ],
        ),
      ],
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat(this.title, this.value, this.icon);
  final String title;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 260,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Icon(icon, color: kPurple),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            color: Colors.white60, fontSize: 12)),
                    const SizedBox(height: 2),
                    Text(value,
                        style: const TextStyle(fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
