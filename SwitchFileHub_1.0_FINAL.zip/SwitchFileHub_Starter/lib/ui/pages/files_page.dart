import 'dart:io';

import 'package:desktop_drop/desktop_drop.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

import '../../core/format.dart';
import '../../core/models.dart';
import '../../state/app_controller.dart';
import '../theme.dart';

bool get _isDesktop =>
    Platform.isWindows || Platform.isLinux || Platform.isMacOS;

class FilesPage extends StatefulWidget {
  const FilesPage({super.key});
  @override
  State<FilesPage> createState() => _FilesPageState();
}

class _FilesPageState extends State<FilesPage> {
  bool _dragging = false;
  bool _showLocal = false; // alternância em telas estreitas

  Future<void> _upload(AppController app, List<String> paths) async {
    final msg = await app.uploadPaths(
        paths, (c) => conflictDialog(context, c));
    if (mounted) showMsg(context, msg);
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    if (!app.connected) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(
            'Conecte-se ao Switch (menu "Conectar Switch") para gerenciar os arquivos do microSD.',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white70, fontSize: 16),
          ),
        ),
      );
    }
    final wide = MediaQuery.of(context).size.width >= 1000;
    final remote = _RemotePane(onUpload: (paths) => _upload(app, paths));
    Widget content;
    if (_isDesktop && wide) {
      content = Row(children: [
        Expanded(
            child: _LocalPane(onSend: (paths) => _upload(app, paths))),
        const VerticalDivider(width: 1),
        Expanded(child: remote),
      ]);
    } else if (_isDesktop) {
      content = Column(children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: SegmentedButton<bool>(
            segments: const [
              ButtonSegment(value: false, label: Text('Switch')),
              ButtonSegment(value: true, label: Text('Computador')),
            ],
            selected: {_showLocal},
            onSelectionChanged: (s) => setState(() => _showLocal = s.first),
          ),
        ),
        Expanded(
          child: _showLocal
              ? _LocalPane(onSend: (paths) => _upload(app, paths))
              : remote,
        ),
      ]);
    } else {
      content = remote;
    }

    return DropTarget(
      onDragEntered: (_) => setState(() => _dragging = true),
      onDragExited: (_) => setState(() => _dragging = false),
      onDragDone: (d) {
        setState(() => _dragging = false);
        final paths = d.files.map((f) => f.path).where((x) => x.isNotEmpty);
        if (paths.isNotEmpty) _upload(app, paths.toList());
      },
      child: Stack(children: [
        content,
        if (_dragging)
          Positioned.fill(
            child: IgnorePointer(
              child: Container(
                color: kPurple.withValues(alpha: 0.18),
                alignment: Alignment.center,
                child: const Text('Solte para enviar ao Switch',
                    style:
                        TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              ),
            ),
          ),
      ]),
    );
  }
}

// ======================================================================
// Painel remoto (Switch)
// ======================================================================

class _RemotePane extends StatelessWidget {
  const _RemotePane({required this.onUpload});
  final void Function(List<String> paths) onUpload;

  Future<void> _pickFiles(BuildContext context) async {
    final files = await FilePicker.pickFiles();
    final paths =
        files.map((f) => f.path).whereType<String>().where((x) => x.isNotEmpty);
    if (paths.isEmpty) {
      if (files.isNotEmpty && context.mounted) {
        showMsg(context, 'O seletor não forneceu o caminho local do arquivo.');
      }
      return;
    }
    onUpload(paths.toList());
  }

  Future<void> _pickFolder(BuildContext context) async {
    final dir = await FilePicker.getDirectoryPath(
        dialogTitle: 'Escolha a pasta a enviar');
    if (dir != null && dir.isNotEmpty) onUpload([dir]);
  }

  Future<void> _download(BuildContext context, AppController app) async {
    final items = app.remoteEntries
        .where((e) => app.remoteSelection.contains(e.name))
        .toList();
    if (items.isEmpty) return;
    String? dest;
    final def = await app.defaultDownloadDir();
    if (!context.mounted) return;
    if (_isDesktop) {
      dest = await FilePicker.getDirectoryPath(
          dialogTitle: 'Escolha onde salvar os downloads');
    } else {
      dest = def.path; // Android: pasta do app (sempre gravável)
    }
    if (dest == null || dest.isEmpty) return;
    if (!context.mounted) return;
    final msg = await app.downloadEntries(
        items, dest, (c) => conflictDialog(context, c));
    if (context.mounted) showMsg(context, msg);
  }

  Future<void> _newFolder(BuildContext context, AppController app) async {
    final name = await promptDialog(context,
        title: 'Nova pasta no Switch',
        label: 'Nome da pasta',
        confirmLabel: 'Criar');
    if (name == null) return;
    final err = await app.makeFolder(name);
    if (context.mounted) showMsg(context, err ?? 'Pasta criada: $name');
  }

  Future<void> _rename(BuildContext context, AppController app) async {
    if (app.remoteSelection.length != 1) return;
    final old = app.remoteSelection.first;
    final name = await promptDialog(context,
        title: 'Renomear no Switch',
        label: 'Novo nome',
        initial: old,
        confirmLabel: 'Renomear');
    if (name == null || name == old) return;
    final err = await app.renameRemote(old, name);
    if (context.mounted) showMsg(context, err ?? 'Renomeado para $name');
  }

  Future<void> _delete(BuildContext context, AppController app) async {
    final items = app.remoteEntries
        .where((e) => app.remoteSelection.contains(e.name))
        .toList();
    if (items.isEmpty) return;
    final hasDir = items.any((e) => e.isDir);
    final ok = await confirmDialog(
      context,
      title: 'Excluir do Switch?',
      message: 'Excluir permanentemente ${items.length} item(ns):\n\n'
          '${items.take(8).map((e) => '• ${e.name}${e.isDir ? '/' : ''}').join('\n')}'
          '${items.length > 8 ? '\n… e mais ${items.length - 8}' : ''}'
          '${hasDir ? '\n\nPastas serão apagadas com TODO o conteúdo.' : ''}'
          '\n\nEsta ação não pode ser desfeita.',
      confirmLabel: 'Excluir',
      danger: true,
    );
    if (!ok) return;
    final err = await app.deleteRemote(items);
    if (context.mounted) showMsg(context, err ?? 'Excluído.');
  }

  Future<void> _report(BuildContext context, Future<String?> f) async {
    final err = await f;
    if (err != null && context.mounted) showMsg(context, err);
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final sel = app.remoteSelection;
    final canOp = !app.busy;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
          child: Row(children: [
            const Icon(Icons.sd_card, color: kBlue),
            const SizedBox(width: 8),
            Expanded(
              child: Text('Switch: ${app.remotePath}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w600)),
            ),
            IconButton(
                tooltip: 'Pasta anterior',
                onPressed: canOp && app.remotePath != '/'
                    ? () => _report(context, app.goParent())
                    : null,
                icon: const Icon(Icons.arrow_upward)),
            IconButton(
                tooltip: 'Atualizar',
                onPressed:
                    canOp ? () => _report(context, app.refresh()) : null,
                icon: const Icon(Icons.refresh)),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 4),
          child: Wrap(spacing: 8, runSpacing: 4, children: [
            FilledButton.icon(
                onPressed: canOp ? () => _pickFiles(context) : null,
                icon: const Icon(Icons.upload_file),
                label: const Text('Enviar arquivos')),
            OutlinedButton.icon(
                onPressed: canOp ? () => _pickFolder(context) : null,
                icon: const Icon(Icons.drive_folder_upload),
                label: const Text('Enviar pasta')),
            OutlinedButton.icon(
                onPressed: canOp ? () => _newFolder(context, app) : null,
                icon: const Icon(Icons.create_new_folder),
                label: const Text('Nova pasta')),
            FilledButton.tonalIcon(
                onPressed: canOp && sel.isNotEmpty
                    ? () => _download(context, app)
                    : null,
                icon: const Icon(Icons.download),
                label: Text('Baixar (${sel.length})')),
            OutlinedButton.icon(
                onPressed: canOp && sel.length == 1
                    ? () => _rename(context, app)
                    : null,
                icon: const Icon(Icons.drive_file_rename_outline),
                label: const Text('Renomear')),
            OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.redAccent),
                onPressed: canOp && sel.isNotEmpty
                    ? () => _delete(context, app)
                    : null,
                icon: const Icon(Icons.delete_outline),
                label: const Text('Excluir')),
          ]),
        ),
        if (app.busy) const LinearProgressIndicator(minHeight: 2),
        Expanded(
          child: app.remoteEntries.isEmpty
              ? const Center(
                  child: Text('Pasta vazia.',
                      style: TextStyle(color: Colors.white54)))
              : ListView.builder(
                  itemCount: app.remoteEntries.length,
                  itemBuilder: (_, i) {
                    final e = app.remoteEntries[i];
                    final selected = sel.contains(e.name);
                    return ListTile(
                      dense: true,
                      selected: selected,
                      selectedTileColor: kPurple.withValues(alpha: 0.15),
                      leading: Checkbox(
                          value: selected,
                          onChanged: (_) => app.toggleSelect(e.name)),
                      title: Row(children: [
                        Icon(e.isDir ? Icons.folder : Icons.insert_drive_file,
                            color: e.isDir ? kFolder : kBlue, size: 20),
                        const SizedBox(width: 8),
                        Expanded(
                            child: Text(e.name,
                                maxLines: 1, overflow: TextOverflow.ellipsis)),
                      ]),
                      subtitle: Text(e.isDir ? 'Pasta' : formatSize(e.size)),
                      trailing: e.isDir ? const Icon(Icons.chevron_right) : null,
                      onTap: e.isDir && canOp
                          ? () => _report(context, app.openDirectory(e.name))
                          : () => app.toggleSelect(e.name),
                    );
                  },
                ),
        ),
      ],
    );
  }
}

// ======================================================================
// Painel local (computador) — somente desktop
// ======================================================================

class _LocalItem {
  _LocalItem(this.path, this.name, this.isDir, this.size);
  final String path;
  final String name;
  final bool isDir;
  final int? size;
}

class _LocalPane extends StatefulWidget {
  const _LocalPane({required this.onSend});
  final void Function(List<String> paths) onSend;
  @override
  State<_LocalPane> createState() => _LocalPaneState();
}

class _LocalPaneState extends State<_LocalPane> {
  String _dir = '';
  List<_LocalItem> _items = [];
  final Set<String> _sel = {};
  String? _error;

  @override
  void initState() {
    super.initState();
    final home = Platform.environment['USERPROFILE'] ??
        Platform.environment['HOME'] ??
        (Platform.isWindows ? r'C:\' : '/');
    _load(home);
  }

  List<String> get _drives => [
        for (final c in 'CDEFGHIJKLMNOPQRSTUVWXYZ'.split(''))
          if (Directory('$c:\\').existsSync()) '$c:\\',
      ];

  Future<void> _load(String dir) async {
    try {
      final items = <_LocalItem>[];
      await for (final e in Directory(dir).list(followLinks: false)) {
        final name = p.basename(e.path);
        if (e is Directory) {
          items.add(_LocalItem(e.path, name, true, null));
        } else if (e is File) {
          int? size;
          try {
            size = await e.length();
          } catch (_) {}
          items.add(_LocalItem(e.path, name, false, size));
        }
      }
      items.sort((a, b) {
        if (a.isDir != b.isDir) return a.isDir ? -1 : 1;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });
      if (!mounted) return;
      setState(() {
        _dir = dir;
        _items = items;
        _sel.clear();
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = 'Não foi possível abrir a pasta: $e');
    }
  }

  void _up() {
    final parent = p.dirname(_dir);
    if (parent != _dir) _load(parent);
  }

  Future<void> _newFolder() async {
    final app = AppScope.of(context);
    final name = await promptDialog(context,
        title: 'Nova pasta', label: 'Nome da pasta', confirmLabel: 'Criar');
    if (name == null) return;
    final err = validateName(name);
    if (err != null) {
      if (mounted) showMsg(context, err);
      return;
    }
    try {
      final d = Directory(p.join(_dir, name));
      if (await d.exists()) throw 'Essa pasta já existe.';
      await d.create();
      app.addHistory(HistoryEntry(
          time: DateTime.now(),
          kind: HistoryKind.localMkdir,
          name: d.path,
          status: 'ok'));
    } catch (e) {
      if (mounted) showMsg(context, 'Falha ao criar pasta: $e');
    }
    await _load(_dir);
  }

  Future<void> _rename() async {
    if (_sel.length != 1) return;
    final app = AppScope.of(context);
    final old = _items.firstWhere((i) => i.path == _sel.first);
    final name = await promptDialog(context,
        title: 'Renomear',
        label: 'Novo nome',
        initial: old.name,
        confirmLabel: 'Renomear');
    if (name == null || name == old.name) return;
    final err = validateName(name);
    if (err != null) {
      if (mounted) showMsg(context, err);
      return;
    }
    final target = p.join(_dir, name);
    try {
      if (FileSystemEntity.typeSync(target) != FileSystemEntityType.notFound) {
        throw 'Já existe um item com esse nome.';
      }
      if (old.isDir) {
        await Directory(old.path).rename(target);
      } else {
        await File(old.path).rename(target);
      }
      app.addHistory(HistoryEntry(
          time: DateTime.now(),
          kind: HistoryKind.localRename,
          name: '${old.name} → $name',
          status: 'ok'));
    } catch (e) {
      if (mounted) showMsg(context, 'Falha ao renomear: $e');
    }
    await _load(_dir);
  }

  Future<void> _delete() async {
    if (_sel.isEmpty) return;
    final app = AppScope.of(context);
    final items = _items.where((i) => _sel.contains(i.path)).toList();
    final ok = await confirmDialog(
      context,
      title: 'Excluir do computador?',
      message: 'Excluir permanentemente ${items.length} item(ns):\n\n'
          '${items.take(8).map((e) => '• ${e.name}${e.isDir ? '/' : ''}').join('\n')}'
          '${items.any((e) => e.isDir) ? '\n\nPastas serão apagadas com TODO o conteúdo.' : ''}'
          '\n\nEsta ação não pode ser desfeita (não vai para a Lixeira).',
      confirmLabel: 'Excluir',
      danger: true,
    );
    if (!ok) return;
    for (final i in items) {
      String? err;
      try {
        if (i.isDir) {
          await Directory(i.path).delete(recursive: true);
        } else {
          await File(i.path).delete();
        }
      } catch (e) {
        err = '$e';
      }
      app.addHistory(HistoryEntry(
          time: DateTime.now(),
          kind: HistoryKind.localDelete,
          name: i.path,
          status: err == null ? 'ok' : 'erro',
          detail: err ?? ''));
    }
    await _load(_dir);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 0),
          child: Row(children: [
            const Icon(Icons.computer, color: kBlue),
            const SizedBox(width: 8),
            Expanded(
              child: Text('Computador: $_dir',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w600)),
            ),
            if (Platform.isWindows)
              PopupMenuButton<String>(
                tooltip: 'Unidades',
                icon: const Icon(Icons.storage),
                onSelected: _load,
                itemBuilder: (_) => [
                  for (final d in _drives)
                    PopupMenuItem(value: d, child: Text(d)),
                ],
              ),
            IconButton(
                tooltip: 'Pasta anterior',
                onPressed: _up,
                icon: const Icon(Icons.arrow_upward)),
            IconButton(
                tooltip: 'Atualizar',
                onPressed: () => _load(_dir),
                icon: const Icon(Icons.refresh)),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 4),
          child: Wrap(spacing: 8, runSpacing: 4, children: [
            FilledButton.icon(
                onPressed: _sel.isEmpty
                    ? null
                    : () => widget.onSend(_sel.toList()),
                icon: const Icon(Icons.upload),
                label: Text('Enviar ao Switch (${_sel.length})')),
            OutlinedButton.icon(
                onPressed: _newFolder,
                icon: const Icon(Icons.create_new_folder),
                label: const Text('Nova pasta')),
            OutlinedButton.icon(
                onPressed: _sel.length == 1 ? _rename : null,
                icon: const Icon(Icons.drive_file_rename_outline),
                label: const Text('Renomear')),
            OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.redAccent),
                onPressed: _sel.isEmpty ? null : _delete,
                icon: const Icon(Icons.delete_outline),
                label: const Text('Excluir')),
          ]),
        ),
        if (_error != null)
          Padding(
            padding: const EdgeInsets.all(8),
            child: Text(_error!,
                style: const TextStyle(color: Colors.redAccent)),
          ),
        Expanded(
          child: ListView.builder(
            itemCount: _items.length,
            itemBuilder: (_, i) {
              final it = _items[i];
              final selected = _sel.contains(it.path);
              return ListTile(
                dense: true,
                selected: selected,
                selectedTileColor: kPurple.withValues(alpha: 0.15),
                leading: Checkbox(
                    value: selected,
                    onChanged: (_) => setState(() {
                          if (!_sel.remove(it.path)) _sel.add(it.path);
                        })),
                title: Row(children: [
                  Icon(it.isDir ? Icons.folder : Icons.insert_drive_file,
                      color: it.isDir ? kFolder : kBlue, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                      child: Text(it.name,
                          maxLines: 1, overflow: TextOverflow.ellipsis)),
                ]),
                subtitle: Text(it.isDir ? 'Pasta' : formatSize(it.size)),
                trailing: it.isDir ? const Icon(Icons.chevron_right) : null,
                onTap: it.isDir
                    ? () => _load(it.path)
                    : () => setState(() {
                          if (!_sel.remove(it.path)) _sel.add(it.path);
                        }),
              );
            },
          ),
        ),
      ],
    );
  }
}
