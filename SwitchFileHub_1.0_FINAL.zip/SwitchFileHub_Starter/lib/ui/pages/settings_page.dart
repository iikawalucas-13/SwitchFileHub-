import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../../core/models.dart';
import '../theme.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final s = app.settings;
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Card(
          child: ListTile(
            leading: const Icon(Icons.folder_special),
            title: const Text('Pasta padrão de downloads'),
            subtitle: Text(app.downloadDir ??
                'Padrão do sistema (Downloads\\SwitchFileHub / pasta do app no Android)'),
            trailing: Wrap(children: [
              IconButton(
                tooltip: 'Escolher',
                icon: const Icon(Icons.edit),
                onPressed: () async {
                  final d = await FilePicker.getDirectoryPath(
                      dialogTitle: 'Pasta padrão de downloads');
                  if (d != null && d.isNotEmpty) await app.setDownloadDir(d);
                },
              ),
              IconButton(
                tooltip: 'Restaurar padrão',
                icon: const Icon(Icons.restore),
                onPressed:
                    app.downloadDir == null ? null : () => app.setDownloadDir(null),
              ),
            ]),
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.sync_alt),
            title: const Text('Transferências simultâneas'),
            subtitle: const Text(
                'Cada transferência usa sua própria conexão FTP. O FTPD costuma '
                'aceitar poucas conexões; use 1–2 se houver falhas.'),
            trailing: DropdownButton<int>(
              value: app.maxConcurrent,
              items: const [1, 2, 3]
                  .map((v) => DropdownMenuItem(value: v, child: Text('$v')))
                  .toList(),
              onChanged: (v) => v == null ? null : app.setMaxConcurrent(v),
            ),
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.list_alt),
            title: const Text('Comando de listagem FTP'),
            subtitle: const Text(
                'Automático tenta MLSD e usa LIST se o servidor não suportar. '
                'Vale na próxima conexão.'),
            trailing: DropdownButton<ListMode>(
              value: s.listMode,
              items: const [
                DropdownMenuItem(value: ListMode.auto, child: Text('Automático')),
                DropdownMenuItem(value: ListMode.mlsd, child: Text('MLSD')),
                DropdownMenuItem(value: ListMode.list, child: Text('LIST')),
              ],
              onChanged: (v) {
                if (v == null) return;
                app.saveSettings(s.copy()..listMode = v);
              },
            ),
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.timer_outlined),
            title: const Text('Tempo limite de conexão (segundos)'),
            trailing: DropdownButton<int>(
              value: const [5, 10, 15, 30, 60].contains(s.timeoutSeconds)
                  ? s.timeoutSeconds
                  : 15,
              items: const [5, 10, 15, 30, 60]
                  .map((v) => DropdownMenuItem(value: v, child: Text('$v')))
                  .toList(),
              onChanged: (v) {
                if (v == null) return;
                app.saveSettings(s.copy()..timeoutSeconds = v);
              },
            ),
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.lock_outline),
            title: const Text('Credenciais'),
            subtitle: const Text(
                'IP, porta e usuário são salvos. A senha NUNCA é gravada em disco.'),
          ),
        ),
      ],
    );
  }
}
