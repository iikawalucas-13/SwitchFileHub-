import 'package:flutter/material.dart';

import '../../core/format.dart';
import '../../core/models.dart';
import '../theme.dart';

class HistoryPage extends StatelessWidget {
  const HistoryPage({super.key});

  static const _icons = {
    HistoryKind.connect: Icons.link,
    HistoryKind.upload: Icons.upload,
    HistoryKind.download: Icons.download,
    HistoryKind.delete: Icons.delete_outline,
    HistoryKind.rename: Icons.drive_file_rename_outline,
    HistoryKind.mkdir: Icons.create_new_folder_outlined,
    HistoryKind.localDelete: Icons.delete_outline,
    HistoryKind.localRename: Icons.drive_file_rename_outline,
    HistoryKind.localMkdir: Icons.create_new_folder_outlined,
  };

  static const _labels = {
    HistoryKind.connect: 'Conexão',
    HistoryKind.upload: 'Envio',
    HistoryKind.download: 'Download',
    HistoryKind.delete: 'Exclusão (Switch)',
    HistoryKind.rename: 'Renomeação (Switch)',
    HistoryKind.mkdir: 'Nova pasta (Switch)',
    HistoryKind.localDelete: 'Exclusão (local)',
    HistoryKind.localRename: 'Renomeação (local)',
    HistoryKind.localMkdir: 'Nova pasta (local)',
  };

  String _two(int n) => n.toString().padLeft(2, '0');

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final items = app.history.reversed.toList();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: Align(
            alignment: Alignment.centerLeft,
            child: OutlinedButton.icon(
              onPressed: items.isEmpty
                  ? null
                  : () async {
                      if (await confirmDialog(context,
                          title: 'Limpar histórico?',
                          message: 'Isso remove apenas o registro, não os arquivos.',
                          confirmLabel: 'Limpar')) {
                        app.clearHistory();
                      }
                    },
              icon: const Icon(Icons.delete_sweep_outlined),
              label: const Text('Limpar histórico'),
            ),
          ),
        ),
        Expanded(
          child: items.isEmpty
              ? const Center(
                  child: Text('Sem registros ainda.',
                      style: TextStyle(color: Colors.white54)))
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: items.length,
                  itemBuilder: (_, i) {
                    final h = items[i];
                    final ok = h.status == 'ok';
                    final t = h.time;
                    final when = '${_two(t.day)}/${_two(t.month)}/${t.year} '
                        '${_two(t.hour)}:${_two(t.minute)}';
                    return Card(
                      child: ListTile(
                        leading: Icon(_icons[h.kind], color: kPurple),
                        title: Text(h.name,
                            maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text(
                          '${_labels[h.kind]} • $when'
                          '${h.bytes != null ? ' • ${formatSize(h.bytes)}' : ''}'
                          '${h.detail.isNotEmpty ? '\n${h.detail}' : ''}',
                        ),
                        isThreeLine: h.detail.isNotEmpty,
                        trailing: Text(h.status,
                            style: TextStyle(
                                color: ok
                                    ? Colors.greenAccent
                                    : (h.status == 'erro'
                                        ? Colors.redAccent
                                        : Colors.amber))),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
