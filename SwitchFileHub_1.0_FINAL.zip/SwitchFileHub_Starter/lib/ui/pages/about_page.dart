import 'package:flutter/material.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(24),
      children: const [
        Text('Switch File Hub 1.0',
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        SizedBox(height: 8),
        Text('Gerenciador de arquivos para o microSD do Nintendo Switch '
            '(servidor FTPD no console), com versões para Windows 11 e Android.'),
        SizedBox(height: 20),
        Text('Segurança', style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(height: 6),
        Text('• FTP não é criptografado: use só em rede local confiável.\n'
            '• Nenhuma exclusão ou substituição acontece sem confirmação.\n'
            '• Arquivos transferidos nunca são executados automaticamente.\n'
            '• A senha FTP não é gravada em disco nem em registros.\n'
            '• Nomes de arquivos vindos do servidor são validados antes de '
            'serem gravados no seu dispositivo.'),
        SizedBox(height: 20),
        Text('Aviso', style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(height: 6),
        Text('Projeto independente, sem vínculo com a Nintendo. Use apenas em '
            'consoles e arquivos que você tem o direito de modificar.'),
      ],
    );
  }
}
