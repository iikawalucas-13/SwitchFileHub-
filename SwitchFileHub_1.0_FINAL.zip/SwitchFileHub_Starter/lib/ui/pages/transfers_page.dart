import 'package:flutter/material.dart';

import '../../core/format.dart';
import '../../core/models.dart';
import '../theme.dart';

class TransfersPage extends StatelessWidget {
  const TransfersPage({super.key});

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final tm = app.transfers;
    final jobs = tm.jobs.reversed.toList();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: Wrap(spacing: 8, runSpacing: 8, children: [
            OutlinedButton.icon(
                onPressed: tm.activeCount == 0 ? null : tm.cancelAll,
                icon: const Icon(Icons.cancel_outlined),
                label: const Text('Cancelar todas')),
            OutlinedButton.icon(
                onPressed: tm.clearFinished,
                icon: const Icon(Icons.cleaning_services_outlined),
                label: const Text('Limpar concluídas')),
          ]),
        ),
        Expanded(
          child: jobs.isEmpty
              ? const Center(
                  child: Text('Nenhuma transferência.',
                      style: TextStyle(color: Colors.white54)))
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: jobs.length,
                  itemBuilder: (_, i) => _JobTile(job: jobs[i]),
                ),
        ),
      ],
    );
  }
}

class _JobTile extends StatelessWidget {
  const _JobTile({required this.job});
  final TransferJob job;

  @override
  Widget build(BuildContext context) {
    final tm = AppScope.of(context).transfers;
    final up = job.direction == TransferDirection.upload;
    final (label, color) = switch (job.state) {
      TransferState.queued => ('Na fila', Colors.white54),
      TransferState.running => (up ? 'Enviando' : 'Baixando', kBlue),
      TransferState.done => ('Concluído', Colors.greenAccent),
      TransferState.failed => ('Falhou', Colors.redAccent),
      TransferState.cancelled => ('Cancelado', Colors.orangeAccent),
      TransferState.skipped => ('Pulado (já existe)', Colors.amber),
    };
    final running = job.state == TransferState.running;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Icon(up ? Icons.upload : Icons.download, color: kPurple),
              const SizedBox(width: 10),
              Expanded(
                child: Text(job.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w600)),
              ),
              Text(label, style: TextStyle(color: color)),
              if (!job.isFinished)
                IconButton(
                    tooltip: 'Cancelar',
                    onPressed: () => tm.cancel(job),
                    icon: const Icon(Icons.close)),
              if (job.state == TransferState.failed ||
                  job.state == TransferState.cancelled)
                IconButton(
                    tooltip: 'Tentar novamente',
                    onPressed: () => tm.retry(job),
                    icon: const Icon(Icons.refresh)),
            ]),
            if (running || job.state == TransferState.queued) ...[
              const SizedBox(height: 6),
              LinearProgressIndicator(value: running ? job.fraction : 0),
              const SizedBox(height: 6),
              Text(
                running
                    ? '${formatSize(job.transferred)} / ${formatSize(job.totalBytes)}'
                        '  •  ${job.speed > 0 ? formatSpeed(job.speed) : '—'}'
                        '  •  restante ${formatEta(job.eta)}'
                        '${job.attempts > 1 ? '  •  tentativa ${job.attempts}' : ''}'
                    : 'Aguardando vaga na fila…',
                style: const TextStyle(color: Colors.white60, fontSize: 12),
              ),
            ],
            if (job.error != null)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(job.error!,
                    style: const TextStyle(
                        color: Colors.redAccent, fontSize: 12)),
              ),
          ],
        ),
      ),
    );
  }
}
