import 'dart:io';

import 'package:flutter/material.dart';

import '../../core/models.dart';
import '../theme.dart';

class DevicesPage extends StatefulWidget {
  const DevicesPage({super.key, required this.go});
  final void Function(int) go;
  @override
  State<DevicesPage> createState() => _DevicesPageState();
}

class _DevicesPageState extends State<DevicesPage> {
  List<String> _ips = [];

  @override
  void initState() {
    super.initState();
    _loadIps();
  }

  Future<void> _loadIps() async {
    try {
      final ifs = await NetworkInterface.list(
          type: InternetAddressType.IPv4, includeLoopback: false);
      final ips = [
        for (final i in ifs)
          for (final a in i.addresses) '${a.address}  (${i.name})',
      ];
      if (mounted) setState(() => _ips = ips);
    } catch (_) {}
  }

  Future<void> _openExchange() async {
    final app = AppScope.of(context);
    const folder = 'SwitchFileHub_Troca';
    var err = await app.goTo('/');
    if (err == null) {
      err = await app.goTo('/$folder');
      if (err != null) {
        err = await app.makeFolder(folder);
        if (err == null) err = await app.goTo('/$folder');
      }
    }
    if (!mounted) return;
    if (err != null) {
      showMsg(context, err);
    } else {
      widget.go(2);
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = AppScope.of(context);
    final platform = Platform.isWindows
        ? 'Windows'
        : Platform.isAndroid
            ? 'Android'
            : Platform.operatingSystem;
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        _tile(Icons.videogame_asset, 'Nintendo Switch',
            app.connected
                ? 'Conectado em ${app.settings.host}:${app.settings.port} (FTPD)'
                : 'Não conectado',
            app.connected ? Colors.greenAccent : Colors.white54),
        _tile(Icons.devices, 'Este dispositivo ($platform)',
            _ips.isEmpty ? 'Sem IP de rede detectado' : _ips.join('\n'),
            Colors.greenAccent),
        const SizedBox(height: 12),
        const Text('Como trocar arquivos entre Windows e Android',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Card(
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'Windows ↔ Android NÃO é uma transferência direta nesta versão. '
              'O intermediário é o microSD do Switch (via FTPD):\n\n'
              '1. Envie os arquivos de um aparelho para a pasta de troca no Switch.\n'
              '2. No outro aparelho, conecte ao mesmo Switch e baixe os arquivos.\n\n'
              'Os dados passam pelo Switch; apague a pasta de troca depois, se quiser '
              'liberar espaço.',
            ),
          ),
        ),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: app.connected ? _openExchange : null,
          icon: const Icon(Icons.folder_shared),
          label: const Text('Abrir pasta de troca (/SwitchFileHub_Troca)'),
        ),
        if (!app.connected)
          const Padding(
            padding: EdgeInsets.only(top: 6),
            child: Text('Conecte ao Switch para usar a pasta de troca.',
                style: TextStyle(color: Colors.white54, fontSize: 12)),
          ),
      ],
    );
  }

  Widget _tile(IconData icon, String title, String sub, Color c) => Card(
        child: ListTile(
          leading: Icon(icon, color: c),
          title: Text(title),
          subtitle: Text(sub),
        ),
      );
}
