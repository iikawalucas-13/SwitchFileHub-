import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../core/format.dart';
import '../core/models.dart';
import '../services/ftp_session.dart';
import '../services/persistence.dart';
import '../services/transfer_manager.dart';

enum LinkState { disconnected, connecting, connected, error }

enum OverwriteChoice { cancel, skipExisting, overwrite }

/// Pergunta ao usuário o que fazer com itens que já existem.
typedef ConflictResolver = Future<OverwriteChoice> Function(
    List<String> conflicts);

class AppController extends ChangeNotifier {
  AppController(this._store) {
    settings = _store.loadConnection();
    history = _store.loadHistory();
    transfers = TransferManager(
      settings: () => settings,
      onFinished: _onTransferFinished,
      maxConcurrent: _store.maxConcurrent,
    )..addListener(notifyListeners);
  }

  final Persistence _store;
  late ConnectionSettings settings;
  late List<HistoryEntry> history;
  late final TransferManager transfers;

  FtpSession? _session;
  LinkState link = LinkState.disconnected;
  String status = 'Abra o FTPD no Switch e informe o IP exibido.';
  String remotePath = '/';
  List<RemoteEntry> remoteEntries = [];
  final Set<String> remoteSelection = {};
  bool busy = false;

  bool get connected => link == LinkState.connected;
  String? get downloadDir => _store.downloadDir;
  int get maxConcurrent => transfers.maxConcurrent;

  // ------------------------------------------------------------- histórico

  void addHistory(HistoryEntry e) {
    history.add(e);
    unawaited(_store.saveHistory(history));
    notifyListeners();
  }

  void clearHistory() {
    history.clear();
    unawaited(_store.saveHistory(history));
    notifyListeners();
  }

  void _onTransferFinished(TransferJob j) {
    final status = switch (j.state) {
      TransferState.done => 'ok',
      TransferState.failed => 'erro',
      TransferState.cancelled => 'cancelado',
      TransferState.skipped => 'pulado',
      _ => 'erro',
    };
    addHistory(HistoryEntry(
      time: DateTime.now(),
      kind: j.direction == TransferDirection.upload
          ? HistoryKind.upload
          : HistoryKind.download,
      name: j.name,
      status: status,
      detail: j.error ??
          (j.direction == TransferDirection.upload
              ? '→ ${j.remoteDir}'
              : '→ ${j.localPath}'),
      bytes: j.state == TransferState.done ? j.totalBytes : null,
    ));
    // Atualiza a listagem remota quando um envio termina na pasta aberta.
    if (j.direction == TransferDirection.upload &&
        j.state == TransferState.done &&
        j.remoteDir == remotePath &&
        connected &&
        !busy) {
      unawaited(refresh(silent: true));
    }
  }

  // -------------------------------------------------------------- conexão

  Future<String> testConnection(ConnectionSettings s) async {
    try {
      return await FtpSession.test(s);
    } catch (e) {
      throw FtpException(redact(e.toString().replaceFirst('Exception: ', ''),
          s.password));
    }
  }

  Future<void> connect(ConnectionSettings s) async {
    settings = s;
    busy = true;
    link = LinkState.connecting;
    status = 'Conectando ao Switch...';
    notifyListeners();
    final session = FtpSession(settings);
    try {
      await session.connect();
      _session = session;
      await _store.saveConnection(settings);
      link = LinkState.connected;
      status = 'Conectado a ${settings.host}:${settings.port}';
      remoteSelection.clear();
      await _reload();
      addHistory(HistoryEntry(
          time: DateTime.now(),
          kind: HistoryKind.connect,
          name: '${settings.host}:${settings.port}',
          status: 'ok'));
    } catch (e) {
      await session.disconnect();
      _session = null;
      link = LinkState.error;
      status = 'Falha na conexão: ${session.friendly(e)}';
      remoteEntries = [];
      addHistory(HistoryEntry(
          time: DateTime.now(),
          kind: HistoryKind.connect,
          name: '${settings.host}:${settings.port}',
          status: 'erro',
          detail: session.friendly(e)));
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  Future<void> disconnect() async {
    transfers.cancelAll();
    final s = _session;
    _session = null;
    link = LinkState.disconnected;
    status = 'Desconectado.';
    remoteEntries = [];
    remoteSelection.clear();
    remotePath = '/';
    notifyListeners();
    if (s != null) await s.disconnect();
  }

  // ------------------------------------------------------------- navegação

  Future<void> _reload() async {
    final s = _session;
    if (s == null) return;
    remotePath = await s.currentDirectory();
    remoteEntries = await s.list();
    remoteSelection.removeWhere((n) => !remoteEntries.any((e) => e.name == n));
  }

  /// Executa uma operação remota exibindo erro amigável; retorna mensagem de
  /// erro ou null em caso de sucesso.
  Future<String?> _guard(Future<void> Function(FtpSession s) op,
      {bool reload = true}) async {
    final s = _session;
    if (s == null || busy) return 'Não conectado.';
    busy = true;
    notifyListeners();
    try {
      await op(s);
      if (reload) await _reload();
      return null;
    } catch (e) {
      if (FtpSession.isNetworkError(e) || !s.connected) {
        link = LinkState.error;
        status = 'Conexão perdida: ${s.friendly(e)}';
      }
      return s.friendly(e);
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  Future<String?> refresh({bool silent = false}) {
    if (silent && busy) return Future.value(null);
    return _guard((s) async {});
  }

  Future<String?> openDirectory(String name) {
    remoteSelection.clear();
    return _guard((s) => s.changeDirectory(name));
  }

  Future<String?> goTo(String absolutePath) {
    remoteSelection.clear();
    return _guard((s) => s.changeDirectory(absolutePath));
  }

  Future<String?> goParent() {
    remoteSelection.clear();
    return _guard((s) => s.changeDirectory('..'));
  }

  void toggleSelect(String name) {
    if (!remoteSelection.remove(name)) remoteSelection.add(name);
    notifyListeners();
  }

  void selectAllRemote(bool all) {
    remoteSelection.clear();
    if (all) remoteSelection.addAll(remoteEntries.map((e) => e.name));
    notifyListeners();
  }

  // ------------------------------------------------------------ operações

  Future<String?> makeFolder(String name) async {
    final err = await _guard((s) => s.makeDirectory(name));
    addHistory(HistoryEntry(
        time: DateTime.now(),
        kind: HistoryKind.mkdir,
        name: joinRemote(remotePath, name.trim()),
        status: err == null ? 'ok' : 'erro',
        detail: err ?? ''));
    return err;
  }

  Future<String?> renameRemote(String oldName, String newName) async {
    final err = await _guard((s) => s.rename(oldName, newName));
    addHistory(HistoryEntry(
        time: DateTime.now(),
        kind: HistoryKind.rename,
        name: '$oldName → ${newName.trim()}',
        status: err == null ? 'ok' : 'erro',
        detail: err ?? ''));
    return err;
  }

  /// Exclui os itens selecionados. A UI DEVE ter confirmado antes.
  Future<String?> deleteRemote(List<RemoteEntry> items) async {
    final errors = <String>[];
    for (final e in items) {
      final err = await _guard((s) =>
          e.isDir ? s.deleteDirectory(e.name) : s.deleteFile(e.name));
      addHistory(HistoryEntry(
          time: DateTime.now(),
          kind: HistoryKind.delete,
          name: joinRemote(remotePath, e.name),
          status: err == null ? 'ok' : 'erro',
          detail: err ?? ''));
      if (err != null) errors.add('${e.name}: $err');
    }
    remoteSelection.clear();
    notifyListeners();
    return errors.isEmpty ? null : errors.join('\n');
  }

  // -------------------------------------------------------- transferências

  /// Envia arquivos e pastas locais para a pasta remota atual.
  /// Retorna mensagem (resumo ou erro).
  Future<String> uploadPaths(
      List<String> paths, ConflictResolver resolve) async {
    if (!connected) return 'Conecte-se ao Switch primeiro.';
    final destDir = remotePath;
    final candidates = <({String local, List<String> rel})>[];
    for (final path in paths) {
      final type = FileSystemEntity.typeSync(path, followLinks: false);
      final base = p.basename(path);
      if (type == FileSystemEntityType.file) {
        candidates.add((local: path, rel: [base]));
      } else if (type == FileSystemEntityType.directory) {
        await for (final f in Directory(path).list(recursive: true)) {
          if (f is File) {
            final rel = p.split(p.relative(f.path, from: path));
            candidates.add((local: f.path, rel: [base, ...rel]));
          }
        }
      }
    }
    if (candidates.isEmpty) return 'Nada para enviar.';

    // Validação de nomes (FAT32/exFAT) antes de enfileirar.
    final invalid = <String>[];
    final valid = candidates.where((c) {
      final bad = c.rel.any((seg) => validateName(seg) != null);
      if (bad) invalid.add(c.rel.join('/'));
      return !bad;
    }).toList();

    // Conflitos no nível superior (itens que já existem na pasta aberta).
    final existingTop = remoteEntries.map((e) => e.name).toSet();
    final conflicts = <String>{};
    for (final c in valid) {
      if (existingTop.contains(c.rel.first)) conflicts.add(c.rel.first);
    }
    var overwrite = false;
    if (conflicts.isNotEmpty) {
      final choice = await resolve(conflicts.toList()..sort());
      if (choice == OverwriteChoice.cancel) return 'Envio cancelado.';
      overwrite = choice == OverwriteChoice.overwrite;
    }

    final jobs = <TransferJob>[];
    for (final c in valid) {
      final dir = c.rel.length > 1
          ? c.rel.sublist(0, c.rel.length - 1).fold<String>(
              destDir, (acc, seg) => joinRemote(acc, seg))
          : destDir;
      int? size;
      try {
        size = File(c.local).lengthSync();
      } catch (_) {}
      jobs.add(TransferJob(
        id: transfers.nextId,
        direction: TransferDirection.upload,
        name: c.rel.join('/'),
        localPath: c.local,
        remoteDir: dir,
        remoteName: c.rel.last,
        totalBytes: size,
        overwrite: overwrite,
      ));
    }
    if (jobs.isNotEmpty) transfers.enqueue(jobs);
    final skippedMsg =
        invalid.isEmpty ? '' : ' ${invalid.length} ignorado(s) por nome inválido.';
    return '${jobs.length} arquivo(s) na fila de envio.$skippedMsg';
  }

  /// Pasta padrão de downloads (configurada ou padrão do sistema).
  Future<Directory> defaultDownloadDir() async {
    final saved = downloadDir;
    if (saved != null && saved.isNotEmpty) return Directory(saved);
    Directory? base;
    try {
      base = Platform.isAndroid
          ? await getExternalStorageDirectory()
          : await getDownloadsDirectory();
    } catch (_) {}
    base ??= await getApplicationDocumentsDirectory();
    return Directory(p.join(base.path, 'SwitchFileHub'));
  }

  Future<void> setDownloadDir(String? dir) async {
    await _store.setDownloadDir(dir);
    notifyListeners();
  }

  void setMaxConcurrent(int v) {
    transfers.maxConcurrent = v.clamp(1, 3);
    unawaited(_store.setMaxConcurrent(transfers.maxConcurrent));
    notifyListeners();
  }

  Future<void> saveSettings(ConnectionSettings s) async {
    settings = s;
    await _store.saveConnection(s);
    notifyListeners();
  }

  /// Baixa itens (arquivos e pastas) da pasta remota atual para [destDir].
  Future<String> downloadEntries(
      List<RemoteEntry> items, String destDir, ConflictResolver resolve) async {
    if (!connected) return 'Conecte-se ao Switch primeiro.';
    final srcDir = remotePath;
    final root = Directory(destDir);
    try {
      await root.create(recursive: true);
    } catch (e) {
      return 'Não foi possível usar a pasta de destino: $e';
    }

    final planned = <({List<String> rel, int? size})>[];
    final expander = FtpSession(settings);
    try {
      for (final e in items) {
        if (validateName(e.name) != null) continue;
        if (e.isDir) {
          await expander.connect();
          final files = await expander.listRecursive(joinRemote(srcDir, e.name));
          for (final f in files) {
            planned.add((rel: [e.name, ...f.relativeSegments], size: f.size));
          }
        } else if (!e.isLink) {
          planned.add((rel: [e.name], size: e.size));
        }
      }
    } catch (e) {
      return 'Falha ao listar pastas remotas: ${expander.friendly(e)}';
    } finally {
      await expander.disconnect();
    }
    if (planned.isEmpty) return 'Nada para baixar.';

    final conflicts = <String>{};
    for (final it in planned) {
      final target = File(p.joinAll([destDir, ...it.rel.map(sanitizeLocalName)]));
      if (target.existsSync()) conflicts.add(it.rel.join('/'));
    }
    var overwrite = false;
    if (conflicts.isNotEmpty) {
      final choice = await resolve(conflicts.toList()..sort());
      if (choice == OverwriteChoice.cancel) return 'Download cancelado.';
      overwrite = choice == OverwriteChoice.overwrite;
    }

    final jobs = <TransferJob>[];
    for (final it in planned) {
      final localPath = p.joinAll([destDir, ...it.rel.map(sanitizeLocalName)]);
      if (!isInsideLocal(destDir, localPath)) continue; // anti-traversal
      final remoteDir = it.rel.length > 1
          ? it.rel
              .sublist(0, it.rel.length - 1)
              .fold<String>(srcDir, (acc, seg) => joinRemote(acc, seg))
          : srcDir;
      jobs.add(TransferJob(
        id: transfers.nextId,
        direction: TransferDirection.download,
        name: it.rel.join('/'),
        localPath: localPath,
        remoteDir: remoteDir,
        remoteName: it.rel.last,
        totalBytes: it.size,
        overwrite: overwrite,
      ));
    }
    transfers.enqueue(jobs);
    return '${jobs.length} arquivo(s) na fila de download → $destDir';
  }

  @override
  void dispose() {
    transfers.removeListener(notifyListeners);
    transfers.dispose();
    unawaited(_session?.disconnect());
    super.dispose();
  }
}
