import 'package:path/path.dart' as p;

/// Tamanho legível (B, KB, MB, GB).
String formatSize(int? bytes) {
  if (bytes == null) return 'Tamanho desconhecido';
  if (bytes < 1024) return '$bytes B';
  if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
  if (bytes < 1024 * 1024 * 1024) {
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
  return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
}

String formatSpeed(double bytesPerSecond) =>
    '${formatSize(bytesPerSecond.round())}/s';

/// Tempo restante legível; null quando não calculável.
String formatEta(Duration? d) {
  if (d == null) return '—';
  final s = d.inSeconds;
  if (s < 60) return '${s}s';
  if (s < 3600) return '${s ~/ 60}min ${s % 60}s';
  return '${s ~/ 3600}h ${(s % 3600) ~/ 60}min';
}

final RegExp _forbidden = RegExp(r'[\x00-\x1F<>:"|?*/\\]');

/// Valida um nome simples de arquivo/pasta (compatível com FAT32/exFAT do
/// microSD e com o Windows). Retorna mensagem de erro ou null se válido.
String? validateName(String raw) {
  final name = raw.trim();
  if (name.isEmpty) return 'Informe um nome.';
  if (name == '.' || name == '..') return 'Nome inválido.';
  if (name.length > 255) return 'Nome muito longo (máx. 255 caracteres).';
  if (_forbidden.hasMatch(name)) {
    return 'O nome não pode conter / \\ : * ? " < > | nem caracteres de controle.';
  }
  if (name.endsWith('.') || name.endsWith(' ')) {
    return 'O nome não pode terminar com ponto ou espaço.';
  }
  return null;
}

/// Torna um nome vindo do servidor seguro para uso local.
String sanitizeLocalName(String name) {
  var s = name.replaceAll(_forbidden, '_').trim();
  while (s.endsWith('.')) {
    s = s.substring(0, s.length - 1);
  }
  if (s.isEmpty || s == '.' || s == '..') s = '_';
  return s;
}

/// Normaliza caminho remoto absoluto. Retorna null se tiver '..' (tentativa
/// de sair do diretório) ou caracteres de controle.
String? normalizeRemotePath(String path) {
  if (RegExp(r'[\x00-\x1F]').hasMatch(path)) return null;
  final parts = <String>[];
  for (final seg in path.split('/')) {
    if (seg.isEmpty || seg == '.') continue;
    if (seg == '..') return null;
    parts.add(seg);
  }
  return '/${parts.join('/')}';
}

String joinRemote(String base, String name) =>
    base == '/' || base.isEmpty ? '/$name' : '$base/$name';

String parentRemote(String path) {
  final n = normalizeRemotePath(path) ?? '/';
  if (n == '/') return '/';
  final i = n.lastIndexOf('/');
  return i <= 0 ? '/' : n.substring(0, i);
}

/// Garante que [candidate] está dentro de [root] (evita path traversal).
bool isInsideLocal(String root, String candidate) {
  final r = p.canonicalize(root);
  final c = p.canonicalize(candidate);
  return c == r || p.isWithin(r, c);
}

/// Remove segredos de textos que vão para logs/histórico.
String redact(String text, String secret) =>
    secret.isEmpty ? text : text.replaceAll(secret, '***');
