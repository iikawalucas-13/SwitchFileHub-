import 'dart:async';

enum TransferDirection { upload, download }

enum TransferState { queued, running, done, failed, cancelled, skipped }

class ConnectionSettings {
  ConnectionSettings({
    this.host = '',
    this.port = 5000,
    this.user = '',
    this.password = '',
    this.timeoutSeconds = 15,
    this.listMode = ListMode.auto,
  });

  String host;
  int port;
  String user;

  /// A senha vive apenas em memória; nunca é gravada em disco nem em logs.
  String password;
  int timeoutSeconds;
  ListMode listMode;

  ConnectionSettings copy() => ConnectionSettings(
        host: host,
        port: port,
        user: user,
        password: password,
        timeoutSeconds: timeoutSeconds,
        listMode: listMode,
      );
}

enum ListMode { auto, mlsd, list }

class RemoteEntry {
  RemoteEntry(this.name, this.isDir, this.size, {this.isLink = false});
  final String name;
  final bool isDir;
  final int? size;
  final bool isLink;
}

class RemoteFileInfo {
  RemoteFileInfo(this.relativeSegments, this.size);
  final List<String> relativeSegments;
  final int? size;
}

class TransferJob {
  TransferJob({
    required this.id,
    required this.direction,
    required this.name,
    required this.localPath,
    required this.remoteDir,
    required this.remoteName,
    this.totalBytes,
    this.overwrite = false,
  });

  final int id;
  final TransferDirection direction;
  final String name;

  /// Upload: arquivo de origem. Download: arquivo de destino final.
  final String localPath;

  /// Diretório remoto absoluto (destino do upload ou origem do download).
  final String remoteDir;
  final String remoteName;
  int? totalBytes;
  final bool overwrite;

  TransferState state = TransferState.queued;
  int transferred = 0;
  double speed = 0;
  Duration? eta;
  String? error;
  DateTime? startedAt;
  int attempts = 0;

  /// true depois que o app começou a escrever o arquivo de destino remoto.
  bool writing = false;
  Completer<void> cancelSignal = Completer<void>();

  double? get fraction {
    final t = totalBytes;
    if (t == null || t <= 0) return state == TransferState.done ? 1.0 : null;
    return (transferred / t).clamp(0.0, 1.0).toDouble();
  }

  bool get isFinished =>
      state == TransferState.done ||
      state == TransferState.failed ||
      state == TransferState.cancelled ||
      state == TransferState.skipped;
}

enum HistoryKind {
  connect,
  upload,
  download,
  delete,
  rename,
  mkdir,
  localDelete,
  localRename,
  localMkdir,
}

class HistoryEntry {
  HistoryEntry({
    required this.time,
    required this.kind,
    required this.name,
    required this.status,
    this.detail = '',
    this.bytes,
  });

  final DateTime time;
  final HistoryKind kind;
  final String name;

  /// ok | erro | cancelado | pulado
  final String status;
  final String detail;
  final int? bytes;

  Map<String, dynamic> toJson() => {
        't': time.millisecondsSinceEpoch,
        'k': kind.name,
        'n': name,
        's': status,
        'd': detail,
        'b': bytes,
      };

  static HistoryEntry? fromJson(Object? j) {
    if (j is! Map) return null;
    try {
      final kind = HistoryKind.values.firstWhere((k) => k.name == j['k']);
      return HistoryEntry(
        time: DateTime.fromMillisecondsSinceEpoch(j['t'] as int),
        kind: kind,
        name: j['n'] as String,
        status: j['s'] as String,
        detail: (j['d'] as String?) ?? '',
        bytes: j['b'] as int?,
      );
    } catch (_) {
      return null;
    }
  }
}
