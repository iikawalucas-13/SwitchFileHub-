import 'package:flutter/material.dart';

import 'services/persistence.dart';
import 'state/app_controller.dart';
import 'ui/app_shell.dart';
import 'ui/theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = await Persistence.open();
  runApp(SwitchFileHubApp(controller: AppController(store)));
}

class SwitchFileHubApp extends StatelessWidget {
  const SwitchFileHubApp({super.key, required this.controller});
  final AppController controller;

  @override
  Widget build(BuildContext context) {
    return AppScope(
      controller: controller,
      child: MaterialApp(
        title: 'Switch File Hub',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: const AppShell(),
      ),
    );
  }
}
